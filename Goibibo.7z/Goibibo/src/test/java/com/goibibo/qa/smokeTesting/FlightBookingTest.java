package com.goibibo.qa.smokeTesting;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.goibibo.qa.base.TestBase;
import com.goibibo.qa.pages.FlightBookingPage;

public class FlightBookingTest extends TestBase{
	FlightBookingPage booking;
	public FlightBookingTest() {
	super();
	}
	
	@BeforeMethod
	public void setup() {
		initialization();
		//action = new Actions(driver); 
 	booking = new FlightBookingPage();      }
	
	@Test
	public void checkAvailableflight() throws InterruptedException {
		booking.source("Hyderabad");
		//booking.sclick();
	}
	

}

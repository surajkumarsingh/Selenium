package com.goibibo.qa.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.goibibo.qa.base.TestBase;

public class FlightBookingPage extends TestBase {

	// Page Factory:-OR
	@FindBy(xpath = "//input[@id='gosuggest_inputSrc']")
	WebElement Source;

	@FindBy(xpath = "//div[@class='col-md-6 col-sm-6 col-xs-12 pad0']")
	WebElement Sclick;

	@FindBy(xpath = "//h1[@class='font30 white lh1-5']")
	WebElement Dclick;

	@FindBy(xpath = "//i[@class='icon-calendar1 ico22 widgetCalIcon ']")
	WebElement ical;

	@FindBy(xpath = "//input[@id='gosuggest_inputDest']")
	WebElement destination;

	@FindBy(xpath = "//input[@type='text' and @class='form-control inputTxtLarge widgetCalenderTxt']")
	WebElement calender;

	@FindBy(xpath = "//i[@class='icon-arrow-down txtgrey ico13 lh1-2 padT5 fr']")
	WebElement itravellers;

	@FindBy(xpath = "//input[@id='adultPaxBox']")
	WebElement adultTraveller;

	@FindBy(xpath = "//select[@id='gi_class']")
	WebElement classes;

	@FindBy(xpath = "//button[@id='gi_search_btn']")
	WebElement getsetgo;

	public FlightBookingPage() {
		PageFactory.initElements(driver, this);
	}
	public void source(String source) throws InterruptedException {
		Source.sendKeys(source);
		Source.click();
		Sclick.click();
	
	}
	public void Destination(String des) {
		destination.sendKeys(des);
	}

	public void sclick() {
		Sclick.click();
	}

	public void dclick() {
		Dclick.click();
	}

	public void calender(String date) {
		js = ((JavascriptExecutor) driver);
		js.executeScript("arguments[0].value='" + date + "';", calender);
	}

	public void traveller(String adults) {
		itravellers.click(); 
		adultTraveller.clear();
		adultTraveller.sendKeys(adults);
	}

	public void Class(int Class) {
		dropdown = new Select(classes);
		dropdown.selectByIndex(Class);
	}

	public void getsetGo() {
		getsetgo.click();
	}
 public void iCal() {
	 ical.click();
 }
}

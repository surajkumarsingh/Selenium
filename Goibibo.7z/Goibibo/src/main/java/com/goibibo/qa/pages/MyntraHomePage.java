package com.goibibo.qa.pages;

import java.util.Iterator;
import java.util.Set;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.goibibo.qa.base.TestBase;

public class MyntraHomePage extends TestBase{

	// Page Factory:- OR
	
			@FindBy(xpath = "//span[@class='desktop-userTitle' and @data-reactid='741']")
			WebElement profile;

			@FindBy(linkText = "LOG IN")
			WebElement login;

			@FindBy(xpath = "//input[@type='email']")
			WebElement email;

			@FindBy(xpath = "//input[@type='password']")
			WebElement pwd;

			@FindBy(xpath = "//input[@name='captcha']")
			WebElement captcha;

			@FindBy(xpath = "//button[@class='login-login-button']")
			WebElement loginBtn;
			
			@FindBy(xpath = "//a[@data-group='men']")
			WebElement men;

			@FindBy(linkText = "T-Shirts")
			WebElement tshirt;
			
			@FindBy(xpath = "//ul[@class='results-base']//li[2]//img")
			WebElement Tshirsts;
			
			@FindBy(xpath = "//div[@class='pdp-add-to-bag pdp-button pdp-flex pdp-center']")
			WebElement addtobag;
			
			@FindBy(xpath = "//button//p[contains(text(), 'M')]")
			WebElement sizeM;
			
			@FindBy(xpath = "//span[contains(text(),'Bag')]")
			WebElement bag;
				
			@FindBy(xpath = "//div[@class='placeOrder-base-button ']")
			WebElement placeOrder;
			
			@FindBy(xpath = "//div[contains(text(), 'continue')]")
			WebElement continueBtn;
			
			@FindBy(xpath = "//li[@id='tab_cod']")
			WebElement cod;
			
			
			          	 
  public MyntraHomePage () {
				PageFactory.initElements(driver, this);
			}
			public void profile() {
				profile.click();
				// action.moveToElement(profile).build().perform();
			}

			public void loginIn() {
				login.click();
			}

			public void login() throws InterruptedException {
				men.click();
				tshirt.click();
				Tshirsts.click();
				Set <String> handler =  driver.getWindowHandles();//** to store child window id
				Iterator<String> it = handler.iterator();//**because Set has no index so we use 
				//Iterator to get id of windows instead of for Loop
				//**Window id is unique and Dynamic
				//it.next();// **give you first object
				String parentWindow = it.next();
				System.out.println( "Parent window id "+parentWindow );
				
				String childWindowId = it.next();
				System.out.println("Child Windows id "+childWindowId);
				
				driver.switchTo().window(childWindowId);
					
				sizeM.click();
				addtobag.click();
				bag.click();
				placeOrder.click();
				
				email.sendKeys("suraj9391@gmail.com");
				pwd.sendKeys("myntra@12");
				// captcha.sendKeys();
				Thread.sleep(5000);
				loginBtn.click();
				continueBtn.click();
				cod.click();
				
				//action.moveToElement(driver.findElement(By.xpath("//ul[@class='results-base']//li[2]//img"))).build().perform();
				//addtobag.click();
				

			}

		}

	

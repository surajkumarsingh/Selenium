package myRunner;

import org.junit.runner.RunWith;

import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;

//@RunWith(Cucumber.class)
@CucumberOptions(
		features = "D:\\Suraj_WorkSpace\\cucumberDemo\\src\\main\\java\\features\\Gmail_Login.feature", //the path of the feature files
		glue={"cucumberDemo.cucumberDemo"})//the path of the step definition files
		

public class GmailRunner extends AbstractTestNGCucumberTests {

}

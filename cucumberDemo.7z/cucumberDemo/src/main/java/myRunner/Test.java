package myRunner;

import org.junit.runner.RunWith;
import cucumber.api.CucumberOptions;
import cucumber.api.junit.Cucumber;
import cucumber.api.testng.AbstractTestNGCucumberTests;



//Uncomment if you are using Junit

//@RunWith(Cucumber.class)

@CucumberOptions(
		features = "D:\\Suraj_WorkSpace\\cucumberDemo\\src\\main\\java\\features\\Test.feature", //the path of the feature files
		glue={"cucumberDemo.cucumberDemo"},//the path of the step definition files
		monochrome= true,
		dryRun= false,
		strict= false)
		
public class Test extends AbstractTestNGCucumberTests {

}

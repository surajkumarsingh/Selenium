package cucumberDemo.cucumberDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GoogleSearch {

	WebDriver driver;
//	@Given("^I navigate to the login page$")
//	public void i_navigate_to_the_login_page() throws Throwable {
//	  System.out.println("Background @Given");
//	  
//	}
//
//	@When("^I submit username and password$")
//	public void i_submit_username_and_password()  {
//		  System.out.println("Background @When");
//	}
//
//	@Then("^I should be logged in$")
//	public void i_should_be_logged_in() {
//		System.out.println("Background @Then");
//	}

	@Given("^user on google HomePage search page$")
	public void user_on_google_HomePage_search_page() {
		driver = new ChromeDriver();
		driver.get("https://www.google.com");
	}

	@When("^user enters \"([^\"]*)\" in search box$")
	public void user_enters_in_serach_box(String text) {
		driver.findElement(By.cssSelector("input[class='gLFyf gsfi']")).sendKeys(text);
		driver.findElement(By.xpath("//div[@class='FPdoLc VlcLAe']//input[@name='btnK'and @value='Google Search']"))
				.click();
	}

	@Then("^google search result show$")
	public void google_search_result_show() {

	}

}

package cucumberDemo.cucumberDemo;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class GmailLogin {
	WebDriver driver;
	
	@Given("^User on gmail login page$")
	public void user_on_gmail_login_page()  {
	   driver = new ChromeDriver();
	    driver.get("https://www.gmail.com");
	    
	}

	@When("^user enter \"([^\"]*)\" and \"([^\"]*)\"$")
	public void user_enter_and(String arg1, String arg2) throws Throwable {
	   
	}

	@When("^click on login$")
	public void click_on_login()  {
	   
	    
	}

	@Then("^successfully login to gmail$")
	public void successfully_login_to_gmail()  {
	   
	   
	}


}

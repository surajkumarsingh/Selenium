package cucumberDemo.cucumberDemo;

import cucumber.api.PendingException;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import junit.framework.Assert;

public class Test {

	@Given("^user print hello world$")
	public void user_print_hello_world()  {
	   System.out.println("hello world");
	}
	@Then("^print how are you$")
	public void print_how_are_you() throws Throwable {
	    System.out.println("How are you");
	   // Assert.assertTrue(false);
	}
	@When("^ask how are you$")
	public void ask_how_are_you() throws Throwable {
	 System.out.println("Scenario 2");
	}

	@Then("^reply I am good$")
	public void reply_I_am_good() throws Throwable {
	  System.out.println("I am good");
	}
}

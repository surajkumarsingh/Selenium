package com.flipkart.smokeTest;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.flipkart.PagesObjects.FilpkartHomePage;
import com.flipkart.base.TestBase;

public class MobileShopTesting extends TestBase {
FlipkartLoginTest login;
FilpkartHomePage shop;
	public MobileShopTesting() {
		super();
	}
	
	@BeforeClass
	public void setup() throws Exception {
		//initialization();
		login = new FlipkartLoginTest();
		login.launch();
		login.login();
		shop = new FilpkartHomePage();
	}
	@Test
	public void click_on_electronics() {
		shop.electronic();
			
	}
	
	@Test
	public void click_on_miMobile() {
		shop.click_on_miMoblie();
	}
}

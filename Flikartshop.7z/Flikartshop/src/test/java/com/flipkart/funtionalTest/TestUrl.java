package com.flipkart.funtionalTest;

import org.testng.annotations.Test;

import com.flipkart.base.TestBase;

public class TestUrl extends TestBase {
CloseUrl close;
	public TestUrl() {
		//super();
	}
	@Test
	public void launch_url() {
		initialization();
		driver.get("https://www.google.com");
      //System.out.println(driver.getPageSource());
		//close.close_browser();
	}
}

package com.flipkart.funtionalTest;

import org.testng.annotations.Test;

import com.flipkart.base.TestBase;

public class CloseUrl extends TestBase  {
	
	public CloseUrl() {
		//super();
	}
	
@Test

public void close_browser() {
	initialization();
	driver.close();
}
}

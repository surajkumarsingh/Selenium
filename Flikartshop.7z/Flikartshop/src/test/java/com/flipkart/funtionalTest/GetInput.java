package com.flipkart.funtionalTest;

public class GetInput{
Input in;
	public static void main(String[] args) {
	
	
	}

}

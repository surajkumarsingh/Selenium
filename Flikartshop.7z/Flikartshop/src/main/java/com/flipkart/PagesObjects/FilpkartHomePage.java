package com.flipkart.PagesObjects;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.flipkart.base.TestBase;

public class FilpkartHomePage extends TestBase{

	//Pagefactory :- OR
	
	@FindBy(xpath="//span[contains(text(),'Electronics')]")
	WebElement electronics;
	
	@FindBy(xpath="//li[@class='_1KCOnI _3ZgIXy']//a[@title ='Mi'and @href='/mobiles/mi~brand/pr?sid=tyy,4io&otracker=nmenu_sub_Electronics_0_Mi']")
	WebElement miMobile;

	
	void FlipkartHomePage(){
		
		PageFactory.initElements(driver, this);
	}
	
	public void electronic() {
	
	//WebElement	elec = electronics;
	action.moveToElement(driver.findElement(By.xpath("//span[contains(text(),'Electronics')]"))).build().perform();	
	
	}
	public void click_on_miMoblie() {
		miMobile.click();
	}
}

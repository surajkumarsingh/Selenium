package net;

import java.net.*;
import java.util.*;

class Test {
	public static void main(String[] args) throws Exception {
		Scanner s = new Scanner(System.in);
		System.out.println("please enter site name");
		String sitename = s.nextLine();
		InetAddress in = InetAddress.getByName(sitename);
		System.out.println("the ip address is:" + in);
	s.close();}
}
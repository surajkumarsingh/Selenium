
public class ElseIfTrue {

	public static void main(String[] args) {
		
		int i=4;
		if(4==i) {
			System.out.println("If 1 condition");	
		}else if(4==i)
			System.out.println("If 2");
		else {
			System.out.println("else");
		}
		
	}

}

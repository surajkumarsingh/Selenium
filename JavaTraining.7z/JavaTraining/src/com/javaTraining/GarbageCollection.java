package com.javaTraining;

public class GarbageCollection {

	public static void main(String[] args) {

		Integer i = new Integer(9);
		System.out.println("Before Nullifying " + i);
		i = null;
		System.out.println("After Nullifying " + i);

		GarbageCollection t1 = new GarbageCollection();
		GarbageCollection t2 = t1;
		System.out.println(t1.hashCode());
		System.out.println(t2.hashCode());
		System.out.println(t1);
		System.out.println(t2);
		t1 = null;
		t2 = null;
		/* Calling garbage Collection by System.gc(); */

//System.gc();
	//	Runtime.getRuntime().gc();
		System.out.println(t1);
		System.out.println(t2);
		Runtime.getRuntime().gc();
		System.out.println(t1);
		System.out.println(t2);
	}

}

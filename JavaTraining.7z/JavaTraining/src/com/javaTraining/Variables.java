package com.javaTraining;

public class Variables {
 int instance=10;
	static int st;

	public static void main(String[] args) {
		Variables s = new Variables();
	    s.instance = 8; s.st=9;
		//System.out.println(instance + " " + st + " ");
		
		Variables s2 = new Variables();
		System.out.println(s2.instance);
		
	}

}

package com.javaProgams;

import java.util.Scanner;

public class Fibbonaci {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the Number:");
		int a = 0;
		int b = 1;
		int c;
		int d = sc.nextInt();
		for (int i = 0; i <= d; i++) {
			if (i == 0) {
				System.out.print(a + " " + b);
				continue;
			}
			if (i >= 2) {
				c = a + b;
				System.out.print(" " + c);
				a = b;
				b = c;
			}
		}
		sc.close();
	}
}

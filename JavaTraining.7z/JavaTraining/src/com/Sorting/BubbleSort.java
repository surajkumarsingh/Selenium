package com.Sorting;

import java.util.Scanner;

public class BubbleSort {
	static {
		System.out.println("************Bubble Sort************");
	}

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.print("Enter the Length:");
		int l = sc.nextInt();// ** Taking length of Array from User
		int k;
		System.out.println("Enter the Values:");

		int[] bSort = new int[l];
		for (k = 0; k < bSort.length; k++) {
			bSort[k] = sc.nextInt();
		}
		System.out.println("Enter 1.For Descending Order");
		System.out.println("Enter 2.For Ascending Order");
		int ch = sc.nextInt();
		int temp;
		
	
		// ** For Descending Order
		if (ch == 1) {
			System.out.println("Before Sorting :");
			for (int i : bSort) {
				System.out.print(" " + i);
			}
			for (int j = 0; j < bSort.length; j++) {
				for (int i = 1; i < bSort.length - j; i++) {
					if (bSort[i - 1] < bSort[i]) {
						temp = bSort[i - 1];
						bSort[i - 1] = bSort[i];
						bSort[i] = temp;
					}
				}

			}
			System.out.println();
			System.out.println("After Sorting :");
			for (int h : bSort) {
				System.out.print(" " + h);
			}
		} // ** for Ascending Order
		else if (ch == 2) {
			System.out.print("Before Sorting :");
			for (int i : bSort) {
				System.out.print(" " + i);
			}
			for (int j = 0; j < bSort.length; j++) {
				for (int i = 1; i < bSort.length - j; i++) {
					if (bSort[i - 1] > bSort[i]) {
						temp = bSort[i - 1];
						bSort[i - 1] = bSort[i];
						bSort[i] = temp;
					}
				}
			}
			System.out.println();
			System.out.print("After Sorting :");
			for (int i : bSort) {
				System.out.print(" " + i);
			}
		} else {
			System.out.println("Enter The Correct Choice");
		}
		ch = sc.nextInt();
		sc.close();
	}
}

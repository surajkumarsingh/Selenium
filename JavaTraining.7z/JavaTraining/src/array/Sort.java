package array;
import java.util.*;
public class Sort {

	public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
System.out.println("Enter the numer:");
int[] a=new int[5];
for(int i=0; i<a.length; i++) {
	a[i]=sc.nextInt();
	
}
int b= a.length;
System.out.println(b);
sc.close();	}

}

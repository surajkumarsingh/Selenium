package array;
import java.util.Scanner;
 class Array2dString {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter name:");
		String[] [] name=new String [3][];
		name[0]=new String[1];
		name[1]=new String[1];
		name[2]=new String[1];
		for(int i=0; i<name.length; i++) {
			for(int j=0; j<name[i].length; j++) {
				
				name[i][j]=sc.nextLine(); //**Take Strings from user**
				
		}
		}          //** After taking all Strings this will execute to take index from user**
System.out.println("Enter index:");
for(int i=sc.nextInt(); i<name.length; i=sc.nextInt()) {
for(int j=sc.nextInt(); j<name[i].length; j=sc.nextInt()) {
	
	
System.out.println(name[i][j]);}

}	sc.close();

}}

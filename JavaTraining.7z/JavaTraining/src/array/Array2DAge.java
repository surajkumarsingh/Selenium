package array;

import java.util.Scanner;

public class Array2DAge {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter age:");
		int b = 0;
		int a = 0;
		int c = 0;
		int[][] age = new int[2][];
		age[0] = new int[1];
		age[1] = new int[1];
		for (int i = 0; i < age.length; i++) {
			for (int j = 0; j < age[i].length; j++) {
				age[i][j] = sc.nextInt();
				b += age[i][j];
				if (i == 0) {
					a += age[0][j];
				}
				if (i == 1) {
					c += age[1][j];

				}
			}
		}
		System.out.print("Total Age:");
		System.out.println(b);
		System.out.println("Average Age of Arts:" + a / age[0].length);
		System.out.println("Average Age of Science:" + c / age[1].length);

		sc.close();
	}

}

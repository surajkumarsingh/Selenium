package array;

public class ObjectArray {

	public static void main(String[] args) {
Object[] a=new Object[10];
a[0]=1;
a[1]="a";
a[8]=4;
System.out.println(a[6]);

	}

}

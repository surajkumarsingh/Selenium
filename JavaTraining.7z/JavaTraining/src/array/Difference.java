package array;
import java.util.Scanner;
public class Difference {

	public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
int i;
int a[]=new int[10];
for(i=0; i<10; i++) {
	a[i]=sc.nextInt();
	
}for(i=0; i<10; i++) {
System.out.println(a[i]);}
	sc.close();}

}

package array;
import java.util.Scanner;
public class HackerRank {

	public static void main(String[] args) {	
	Scanner sc=new Scanner(System.in);
	int[] a=new int[10];
	for(int i=0; i<a.length; i++) {	
	a[i]=sc.nextInt();
	}for(int i=0;i<a.length; i++ ) {
		
	
	for(int j=0; j<100; j++) {
	        	
if(Math.pow(2,j)==a[i]) { System.out.println("1"); }
 //if(Math.pow(2,j)!=a[i]) {System.out.println("0");}
}
	}
sc.close();}}
package array;
import java.util.*;
public class Declaration {

	public static void main(String[] args) {
   /*int[] a= {9,9,9};
   int []b;
   b=new int[8];*/
		Scanner sc=new Scanner(System.in);
		int r=sc.nextInt();
		int c=sc.nextInt();
		int [][] a=new int[r][c];
		System.out.println(a[c].length);
		

	}

}

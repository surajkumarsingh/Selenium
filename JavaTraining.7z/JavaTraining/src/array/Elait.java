package array;

public class Elait {

	public static void main(String[] args) {
	int[] a=new int[8];
	for(int i=1; i<a.length;i=i+2) {
	a[i]=1;	
		
	}

System.out.println(a[4]);	}
}

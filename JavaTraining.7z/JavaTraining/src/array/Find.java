package array;
//import java.util.Scanner;

import java.util.Scanner;

 class Find {   //find other alternative

    public static void main(String[] args) {
            Scanner sc=new Scanner(System.in);
            System.out.println("================================");
            for(int i=0;i<3;i++)
            {
                String s1=sc.next();
                int x=sc.nextInt();
          System.out.printf("%-15s%03d%n", s1, x);
                /*  if(x<=99){ 
              System.out.println(s1+   "   "+          "0"+x);    }else
                
                System.out.println(s1+      "    "        +x);*/
            }
            System.out.println("================================");

   sc.close(); }
}












//public class Find {
	

	/*public static void main(String[] args) {
		   Scanner scan = new Scanner(System.in);
	         int i = scan.nextInt();
	         double d=scan.nextDouble();
	         scan.nextLine();
	         String s=scan.nextLine();
	        System.out.println("String: " + s);
	        System.out.println("Double: " + d);
	        System.out.println("Int: " + i);
	  scan.close();  }*/
	//}
	/*	int[] arr = {6,9,5,4};
		find(arr,6);
	
	}


static String find(int[]arr, int k) {
	for(int i=0; i<arr.length; i++) {
	if(arr[i]==k) {
		return "YES";
	}
	}return "NO";
}
          }*/
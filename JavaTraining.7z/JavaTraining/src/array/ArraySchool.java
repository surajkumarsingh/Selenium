package array;
import java.util.Scanner;

public class ArraySchool {
public static void main(String[] args) {
	String b="Z";

	System.out.println("Enter The Schools:");
	Scanner sc=new Scanner(System.in);
	String chen[]= new String[5];
	  for(int i=0; i<chen.length; i++) {
		  chen[i]=sc.nextLine();
	  }
		  for(int j=0; j<chen.length; j++ ) {
			  
			  for(int i=0; i<chen[j].length(); i++) {
				  if(String.valueOf(chen[j].charAt(i)).toUpperCase().equals(b)) {
					  System.out.println("Contains z:"+chen[j]);
					  break;
				  }
				 
		    }
	}
sc.close();}
}
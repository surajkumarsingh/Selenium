package array;
import java.util.Scanner;
public class Indexlargest {

	public static void main(String[] args) {
		int inde = 0;
		int index= 0;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the values:");
		int[][]a=new int[3][4];
		for(int i=0; i<a.length; i++) {
			for(int j=0; j<a[i].length; j++) {
				a[i][j] = sc.nextInt();
			}
		}
		int max = a[0][0];
	
		for(int i=0; i<a.length; i++) {
			for(int j=0; j<a[i].length; j++) {
			if(max < a[i][j]) {
				max = a[i][j];
				inde = i;
				index = j;
				
				
			}
		}

	}System.out.println("index of largest number:"+inde+" "+index);	
		sc.close();}
	}

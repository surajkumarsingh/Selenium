package String;

public class Methods {

	public static void main(String[] args) {
String s = "How are you?";
System.out.println(s.endsWith("?"));
System.out.println(s.startsWith("H"));

System.out.println(s.substring(2));
System.out.println(s.substring(4,12));

StringBuffer sb=new StringBuffer("rattaiah");
String str=" salary ";
int a=60000;
sb.append(str);
sb.append(a);
System.out.println(sb.charAt(18));

StringBuffer sb2=new StringBuffer("suraj");
sb2.insert(0,"hi ");
System.out.println(sb2);

StringBuffer sb3=new StringBuffer("hi suraj hi");
sb3.replace(0,2,"oy");
System.out.println("after replaceing the string:-"+sb3);

	}

}

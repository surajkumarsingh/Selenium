package String;
import java.util.Scanner;
public class Wrapper {

	public static void main(String[] args) {
		System.out.println("Enter the number");
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		int i=Integer.parseInt(s.trim());
		System.out.println(i);
		
sc.close();
	}

}

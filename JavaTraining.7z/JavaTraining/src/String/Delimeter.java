package String;

import java.util.*;

public class Delimeter {

	private static Scanner scanner;

	public static void main(String[] args) {
		String input = "7 tea 12 coffee";
		scanner = new Scanner(input);
		Scanner s = scanner.useDelimiter("\\s");
		int a  = s.nextInt();
		System.out.println(a);
		//System.out.println(s.nextInt());
		System.out.println(s.next());
		System.out.println(s.nextInt());
		System.out.println(s.next());
		s.close();
	}
}

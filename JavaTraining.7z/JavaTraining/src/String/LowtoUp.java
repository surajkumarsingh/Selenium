package String;
import java.util.Scanner;
public class LowtoUp {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
	System.out.println("Enter string:");	
String a=sc.nextLine();
System.out.println(a.toUpperCase());
sc.close();	}

}

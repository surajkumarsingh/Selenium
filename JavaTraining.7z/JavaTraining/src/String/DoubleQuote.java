package String;

public class DoubleQuote {

	public static void main(String[] args) {
		String s = "\"hjjj\" ";
		System.out.println(s);
	}

}

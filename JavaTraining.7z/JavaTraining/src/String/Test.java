package String;

public class Test {

	public static void main(String[] args) {
		// String s= new String("String");
		String s1 = "String";
		String s = new String("String");
		String s2 = "String";

		// StringBuffer s2=new StringBuffer("String");

		System.out.println(s == s1);
		/*
		 * System.out.println(s.equals(s1)); System.out.println(s.hashCode());
		 * System.out.println(s1.hashCode())
		 */;
		System.out.println(s == s2);
		System.out.println(s1 == s2);
		/*
		 * System.out.println(s2); s2.append("Buffer"); System.out.println(s2);
		 * s2.reverse(); System.out.println(s2);
		 */
		s1 = "abc" + s2;

		StringBuilder sb1 = new StringBuilder("Java");
		String sb2 = "Love";
		sb1.append(sb2);
		System.out.println(sb1.substring(4));
		int foundAt = sb1.indexOf(sb2);
		System.out.println(sb1 + " " + sb2);
		System.out.println(foundAt);
	}

}

package String;

import java.util.Scanner;

public class RemoveWhiteSpace {
	public static void main(String[] args) {
		Scanner sc  = new Scanner(System.in);
	
		String s = sc.nextLine();
		
	System.out.println(s.replaceAll("\\s{2,}", " ").trim());
		
//		int len = s.length();
//		char space = 32;
//		for(int i = 0; i < len; i++) {
//			if (s.charAt(i)!=space) {
//				System.out.print(s.charAt(i));
//			
//			}
//
//			else if(s.charAt(i)==space){
//				System.out.print(" ");			
//			}
//			else if(s.charAt(i)==space){
//				System.out.print(" ");
//		}
//		System.out.println(space);
//		System.out.println(len);
//	
		sc.close();		
	}
		
}

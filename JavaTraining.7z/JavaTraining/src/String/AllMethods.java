package String;
import java.util.Scanner;
public class AllMethods {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		String s="abc";
		String s1=new String ("abc");
		String s3=s1+s;
		String s4="abc";
		StringBuffer s5=new StringBuffer("ABC");
		System.out.println(s==s1);
		System.out.println(s.hashCode());
		System.out.println(s1.hashCode());
		System.out.println(s.equals(s1));
		System.out.println(s4==s);/** fgggh **/
		System.out.println(s.toString());
		/*System.out.println(s1);
		System.out.println(s3);
		System.out.println(s4);
		System.out.println(s5);}*/
		String s6=sc.nextLine();
	String s8=" ";
		char s7=' ';
		System.out.print(s6.charAt(0));
		//System.out.println(s6.charAt(5));
for(int i=0; i<s6.length(); i++) {
	s8= s8+s6.charAt(i);
	if(s6.charAt(i)==s7) {

		System.out.print(s6.charAt(i+1));
		}
}System.out.print(s8);
sc.close();}}

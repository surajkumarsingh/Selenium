package String;
import java.util.Scanner;
public class FirstCap {

	public static void main(String[] args) {
Scanner sc=new Scanner(System.in);
String s1=sc.nextLine();
char a=' ';
String s2="";
for(int i=0; i<s1.length(); i++) {
if(s1.charAt(i)==a) {
	s2=s2+Character.toUpperCase(s1.charAt(i+1));
	System.out.print(s1.charAt(i)+s2);
	
}

	}

sc.close();}}

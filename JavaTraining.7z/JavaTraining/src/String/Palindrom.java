package String;
import java.util.Scanner;
public class Palindrom {

	public static void main(String[] args) {
		String str, rev=null;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the word:");
		str=sc.nextLine();
		for(int i = str.length()-1; i>=0; i--) {
			rev =rev + str.charAt(i);
			if(str.equalsIgnoreCase(rev)) {
				
				System.out.println(str+" is Palindrome");}
				else 
					System.out.println(str+" is not Palindrome");
			
		}
sc.close();	}

}

package String;
import java.util.Scanner;
public class Duplicate {

	public static void main(String[] args) {
		String s1=" ";
	Scanner sc=new Scanner(System.in);
String s=sc.nextLine();

for(int i=0; i<s.length(); i++) {
if(!s1.contains(s)) {	
s1=s;	}
}
sc.close();}

}

package String;
import java.util.Scanner;
public class Reverse {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in); 
		System.out.println("Enter the String:");
		String s=sc.nextLine();
		for(int i=s.length()-1; i<=s.length(); i--) {
		System.out.print(s.charAt(i));	
		if(i==0) {break;
			
		}
       /* StringBuffer a=new StringBuffer(sc.nextLine());
        a.reverse();
        System.out.println(a);*/
	sc.close();}

}}

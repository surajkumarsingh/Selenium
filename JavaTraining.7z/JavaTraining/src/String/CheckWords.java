package String;
import java.util.Scanner;
public class CheckWords {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter the String:");
	String a=sc.nextLine();
	System.out.println(a.length());
	sc.close();}

}

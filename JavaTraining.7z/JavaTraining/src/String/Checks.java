package String;
import java.util.Scanner;
public class Checks {

	public static void main(String[] args) {
		String k="s";
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the Sentence:");
		String a=sc.nextLine();
		//String [] b=a.toCharArray();
		for(int i=0; i<a.length(); i++) {
			for(int j=0; j<j; j++) {
			  if(String.valueOf(a.charAt(j)).toUpperCase().equals(k)) {
		
		
			System.out.println("Contains 's' :");}}
			
			sc.close();		}
			 
	

}}

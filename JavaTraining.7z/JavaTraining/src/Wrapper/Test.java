package Wrapper;

public class Test {

	public static void main(String[] args) {
		@SuppressWarnings("deprecation")
		Integer i1 = new Integer(100);
		System.out.println(i1);
		System.out.println(i1.toString());
		Integer i2 = new Integer("1000");
		System.out.println(i2);
		System.out.println(i2.toString());
		/*Integer i3 = new Integer("ten");// java.lang.NumberFormatException
		System.out.println(i3);*/
		boolean b = Boolean.parseBoolean("true");
		System.out.println(b);
		
	}

}

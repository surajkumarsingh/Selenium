package Wrapper;

public class ValueOf {

	public static void main(String[] args) {
		/* we are able to 
		 * create wrapper 
		 * object in two ways.
		 * */
		// constructor approach to create wrapper object
		Integer i1 = new Integer(100);
		System.out.println(i1);
		Integer i2 = new Integer("100");
		System.out.println(i2);
	
		// valueOf() method to create Wrapper object
		Integer a1 = Integer.valueOf(10);
		System.out.println(a1);
		Integer a2 = Integer.valueOf("1000");
		System.out.println(a2);
	}

}

package Wrapper;

public class Conversion {
	public static void main(String[] args) {
		int a = 300;
		int b = 200;
		System.out.println(a + b);
		
		Integer in = new Integer("100");
		Integer in2 = new Integer(200);
		System.out.println(in+in2+" "+in.toString()+" "+in2.toString());
		
		// primitive to String object
		String str1 = String.valueOf(a);
		String str2 = String.valueOf(b);
		System.out.println(str1 + str2);
		
		//String to Primitive
		int i =Integer.parseInt(str1);
		int i2 =Integer.parseInt(str2);
		System.out.println(i+i2);
	}
}

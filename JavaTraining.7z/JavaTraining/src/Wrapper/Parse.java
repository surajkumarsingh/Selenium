package Wrapper;

import java.util.concurrent.TimeUnit;

public class Parse {
	public static void main(String[] args) {
	//	String str1 = "9:45";
		String str2 = "100";
		//System.out.println(str1 + str2);
		String time = "1:50";
		String[] split = time.split(":"); 
		int i = split.length;
		for(int j=0; j<=i-1; j++) {
			System.out.println(split[j]);
		}
		
		if(split.length == 2) { 
		        float minutes = TimeUnit.HOURS.toHours(Integer.parseInt(split[0])) + 
		                         Integer.parseInt(split[1]);
		          
		        System.out.println(minutes);
	
		        
	// parseXXX() conversion of String to primitive type
	//	int a1 = Integer.parseInt(str1);
		float a2 = Float.parseFloat(str2);
		//System.out.println(a1);
	}

}}

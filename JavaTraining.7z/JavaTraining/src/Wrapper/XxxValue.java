package Wrapper;

public class XxxValue {
	public static void main(String[] args) { 
		
		/*it is used to convert 
		 * wrapper object into 
		 * corresponding primitive value.  
		 */
		
		//** valueOf() method to create Wrapper object
		Integer a1 = Integer.valueOf(10);
		System.out.println(a1);
		Integer a2 = Integer.valueOf("1000");
		System.out.println(a2);
		Integer i =10;
		//** xxxValue() [wrapper object into primitive value]
		int x1 = a1.intValue();
		byte x2 = a1.byteValue();
		double x3 = a1.doubleValue();
		System.out.println("int value=" + x1);
		System.out.println("byte value=" + x2);
		System.out.println("double value=" + x3);
		System.out.println(i);
		System.out.println(i.toString());
		int a= new Integer(i);
		System.out.println(a);
	}

}

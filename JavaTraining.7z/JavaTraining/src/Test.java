
import java.util.*;

class Test {
	public static void main(String[] args) {
		ArrayList<Emp> al = new ArrayList<Emp>();
		al.add(new Emp(333, "ratan"));
		al.add(new Emp(222, "anu"));
		al.add(new Emp(111, "Sravya"));
		Collections.sort(al);
		Iterator<Emp> itr = al.iterator();
		while (itr.hasNext()) {
			Emp e = (Emp) itr.next();		
			System.out.println(e.eid + "---" + e.ename);
		}
	}
}

class Emp implements Comparable<Emp> {
	int eid;
	String ename;

	Emp(int eid, String ename) {
		this.eid = eid;
		this.ename = ename;
	}

	public int compareTo(Emp e) {
		return ename.compareTo(e.ename);
	}
}
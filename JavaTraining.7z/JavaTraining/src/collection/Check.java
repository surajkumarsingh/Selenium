package collection;

import java.util.*;

class Check {
	public static void main(String args[]) {

		HashSet al = new HashSet();
		al.add("Ravi");
		al.add("Vijay");
		al.add("Ravi");
		al.add("Ajay");
		al.add(5);

		Iterator<String> itr = al.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
package collection;
import java.util.*;
public class HashMaP {

	public static void main(String[] args) {

HashMap map = new HashMap();
map.put(9, "suraj");

map.put(5, "A9601");
map.put(null, "null");
map.put(2, "kumar");
// keySet() to get all keys

Set key = map.keySet();
System.out.println("keys " +key);

//setvalues() to get all values

Collection c = map.values();

System.out.println("Values " +c);

//entrySet() to get all key-values pairs

Set ss = map.entrySet();

System.out.println("EntrySet " +ss);
		

	}

}

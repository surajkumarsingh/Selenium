package collection;

import java.util.*;

public class ArrayLis {
	public static void main(String[] args) {
		ArrayList al = new ArrayList();
	
    	al.add(10); // AutoBoxing
		al.add('a'); // AutoBoxing
		al.add(10.5);// AutoBoxing
		System.out.println(al);
	}
}

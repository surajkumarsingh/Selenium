package inheritance;

public class Call {
	public static void main(String[] args) {
		Childl a = new Childl();//Call both Parent and child
	//	Parent a = new Parent();//call only Parent
		//Parent a = new Childl();// call only Parent
		//Childl a = new Parent();//**error down casting 
		Composition c = new Composition();
		c.call();
		a.call();
		a.call();
		System.out.println(a);
		
	}
}
	class Parent{
		int a=9;
public void call() {
	
	System.out.println("Parent");
}
	}
class Childl extends Parent{
	int a=6;
	public void call() {
		System.out.println("child");
		super.call();
		System.out.println(super.a);
		System.out.println(a);
		System.out.println(this.a);
		System.out.println(super.a+this.a);
	}
	
	
	
}
package inheritance;

class Kid extends Father {

	public void fa() {
		System.out.println("kid");
	}

	public void kid() {
		System.out.println("Kid");
	}

	public static void main(String[] args) {
		Father fa = new Father();
		fa.fa();
	}
}

class Father {

	public void fa() {
		System.out.println("fa");

	}

}

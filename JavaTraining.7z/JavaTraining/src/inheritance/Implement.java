package inheritance;

public class Implement implements ITest{

public static void main(String[] args) {
	System.out.println(i);
new Implement().test();
}
@Override
public  void test() {
	
		System.out.println(i);
}
}

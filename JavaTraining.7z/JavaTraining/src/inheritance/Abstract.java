package inheritance;

public abstract class Abstract {
	 protected static String name;
	 public Abstract  (String name) {
	 this.name = name;
	 }
	 public String getName() { return name; }
	 public abstract void buy();

}
 class Impl extends Abstract{
	
	public Impl() {
		super(name);
		// TODO Auto-generated constructor stub
	}


	public static void main(String[] args) {
	Impl ab = new Impl();
		
	}
	

	/*public Impl(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}*/

	@Override
	public void buy() {
		// TODO Auto-generated method stub
		
	}
	
	
	
}
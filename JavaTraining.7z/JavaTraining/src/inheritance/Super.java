package inheritance;

public class Super {
	Super(String name){
		System.out.println("super");
	}
}
class Child{
	Child(){
		
	}public static void main(String[] args) {
	
}}
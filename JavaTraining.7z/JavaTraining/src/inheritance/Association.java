package inheritance;


class Teacher {

	int teach() {
		System.out.println("Teaches java");
		return 10;
	}
	
}
class Students{
	
	public static void main(String[] args) {
		Teacher t = new Teacher();
	int a=	t.teach();
	System.out.println(a);
	}
	
}
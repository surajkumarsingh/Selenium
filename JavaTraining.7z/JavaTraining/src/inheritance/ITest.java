package inheritance;

public interface ITest {
int i=9;

void test();
}

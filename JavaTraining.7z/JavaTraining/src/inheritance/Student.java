package inheritance;


class Student{
	
	String Name;
	Address addr;
	public Student(String name,Address addr)
	{
		Name=name;
		this.addr=addr;
		
	}
	void display() {
		System.out.println("********Student Details**********");
		System.out.println(Name);
		System.out.println(addr.city+" "+addr.state);
		
		
	}
	public static void main(String[] args) {
		new Student("suraj",new Address("Patna","Bihar")).display();
		
		
	}
	
	
	
}
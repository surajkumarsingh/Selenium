package inheritance;

public class mainOverload {

	public static void main(String[] args) {
	System.out.println("1");
abc(args);

	}
	public static void abc(String[] args) {
		
System.out.println("2");
main();
	}
	public static void main() {
	
System.out.println("3");

	}
public static void main(int a) {
	
}
}

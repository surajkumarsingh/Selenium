package inheritance;

class Address {

	String city;
	String state;

	public Address(String city, String state) {

		this.city = city;
		this.state = state;

	}
}
package inheritance;

 class A {
	 public static void main(String[] args) {
			
		 A a=new B();
		 A a2= new A();
		 a2.p();
		 A a1= new C();
		 a1.p();
		 B b = new B();
		 b.check();
		 a.p();
		
	 }
  void p() {
  System.out.println("Parent");
	}
}
 
 class B extends A {
	void p() {
		System.out.println("Child");
		
		}
	void check() {
		System.out.println("che");
	}}
	class  C extends A{
		
		void p() {
			System.out.println("dmd");
		}
	}
	

		


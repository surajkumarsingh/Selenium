package inheritance;

public class CoVarient {
 CoVarient  m1() {
	 System.out.println(" int m1");
	return new CoVarient();
	 
	 
 }
}
class Ba extends CoVarient{
	
	CoVarient m1(){
		
		System.out.println("B m1");
		return null;
	}
	public static void main(String[] args) {
		
	}
}
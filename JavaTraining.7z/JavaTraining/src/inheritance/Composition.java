package inheritance;

public class Composition {

	public void call() {
		System.out.println("Call");
	}
	
}


import java.awt.*;

class Eawt extends Frame {
	Eawt() {
		setVisible(true);
		setSize(500, 500);
		setTitle("myframe");
		setBackground(Color.green);
	}

	public static void main(String[] args) {
		Eawt f = new Eawt();
	}
}
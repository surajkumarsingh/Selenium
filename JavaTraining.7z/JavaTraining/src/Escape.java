
public class Escape {
	public static void main(String[] args)
	
	{ 
		
		String s = "";
		System.out.println("Hello \t World");
	System.out.println("Hello\bWorld");
	System.out.println("Hello\nWorld");
	System.out.println("hi Hello\rWorld xxxx hi anu");
	System.out.println("Hello \f World \f hi anu");
	System.out.println("Hello World 'ratan'");
	System.out.println("Hello World \"Anu\"");
	System.out.println("Hello\\World");
System.out.println(s.hashCode());	}

}

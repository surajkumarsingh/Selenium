package InnerClass;

public class Demo {
	int out = 1;

	public void outer() {

		System.out.println(out + " ");
	}

	class Test {
		public void main() {
			int in = 2;
			System.out.println(out + " " + in);
			outer();
		}
	}

	public static void main(String[] args) {
		Demo d = new Demo();
		d.outer();
		Demo.Test t = d.new Test();
		t.main();

	}
}

package ploymorphism;

public class MainOverload {

	public static void main(String[] args) {
System.out.println("main 1");
main(2);
main();
main();

	}

	public static void main(String[][] args) {
System.out.println("main 2");
	}

	public static void main(int i) {
System.out.println("main 3 ");
	}

	void main(int i, int j) {
System.out.println("main 5");
	}
	public static void main() {
System.out.println("main 4");
	}


}

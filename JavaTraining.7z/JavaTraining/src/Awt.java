import java.awt.*;

class Awt extends Frame {
	public static void main(String[] args) {
		Awt t = new Awt();
		t.setVisible(true);
		t.setSize(500, 500);
		t.setTitle("myframe");
		t.setBackground(Color.red);
	}

	public void paint(Graphics g) {
		Font f = new Font("arial", Font.ITALIC, 25);
		g.setFont(f);
		g.drawString("hi how r u", 100, 100);
	}
}

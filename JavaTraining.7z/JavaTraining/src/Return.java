
@FunctionalInterface
interface Return {
	public void turn();

	public static void main(String[] args) {
		Return a = () -> {
			System.out.println("TEST");
		};
		a.turn();
	}
}

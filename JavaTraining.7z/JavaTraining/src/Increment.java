
public class Increment {

	public static void main(String[] args) {
		
int n = 3;
int k = 3;
//int k = n+1;
System.out.println(++n);
System.out.println(k++);
System.out.println(k);


	}

}

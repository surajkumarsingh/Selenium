package Exception;

public class ExcepCheck {

	public void m1() {

		try {
			int a = 10 / 0;
		} catch (Exception e) {
System.out.println(e);
		}
	}

	public void m2() {
		m1();

	}

	public void m3() {
		m2();
	}

	public static void main(String[] args) {

		ExcepCheck a = new ExcepCheck();
		a.m3();
	}

}

package Exception;

public class Checked {

	public static void main(String[] args) {
		try {
			int j=10/0;
		} catch (Exception e) {
			int i=10/0;
			System.out.println(i);
			e.printStackTrace();
		}
		System.out.println("checked");
	}

}

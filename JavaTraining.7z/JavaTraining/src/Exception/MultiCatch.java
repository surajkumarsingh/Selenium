package Exception;

import java.util.Scanner;

public class MultiCatch {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		try {
			System.out.println(10 / n);
			System.out.println("Suraj".charAt(n));
		} catch (ArithmeticException ae) {
			System.out.println("Divide by Zero");
		} catch (StringIndexOutOfBoundsException se) {
			System.out.println("String Index Out Of Bound");
		}
		System.out.println("rest of the code");
		sc.close();
	}
}

package Exception;

public class Throws {

	void studentDetails() throws InterruptedException {
		System.out.println("suneel babu is sleeping");
		Thread.sleep(3000);
		System.out.println("do not disturb sir......");
	}

	void hod() throws InterruptedException {
		studentDetails();
	}

	void principal() {
		try {
			hod();
		} catch (InterruptedException ie) {
			ie.printStackTrace();
		}
	}

	void officeBoy() {
		principal();
	}

	public static void main(String[] args) {
		Throws  t = new Throws ();
		t.officeBoy();
	}

}

package Exception;

public class Excep {

	public static void main(String[] args) {
		System.out.println("connection established");
		System.out.println("excetion");
		try {
			int a = 5 / 0;
		} catch (Exception e) {
			System.out.println(e);

		} finally {
			System.out.println("conection closed");
		}
		System.out.println("g");
			}
	
}

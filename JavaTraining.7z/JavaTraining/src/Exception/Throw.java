package Exception;

import java.util.*;

public class Throw {
	static void validate(int age) {
		if (age < 18) {
			throw new ArithmeticException("not eligible for vote");
		} else {
			System.out.println("welcome to the voting");
		}
	}

	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("please enter your age ");
		validate(s.nextInt());
		System.out.println("rest of the code");
		s.close();
	}

}

package Exception;

public class TryCatch {
	public static void main(String[] args) {
		System.out.println("start");

		try {
			System.out.println("suraj");
			try {
				System.out.println(10 / 0);// ** Rest of the code in try block is not executed**
				System.out.println("kumar");
			} catch (Exception e) {
				// TODO: handle exception
			}
		} catch (Exception e) {

			System.out.println("catch code");

		}
		System.out.println("end");
	}
}

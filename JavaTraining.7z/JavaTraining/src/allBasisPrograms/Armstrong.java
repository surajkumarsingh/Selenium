package allBasisPrograms;

import java.util.Scanner;

public class Armstrong {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int userin = sc.nextInt(), remainder, arm = 0, check = userin;

		while (check > 0) {

			remainder = check % 10;
			remainder = remainder * remainder * remainder;
			arm = arm + remainder;
			check = check / 10;
		}
		if (userin == arm) {
			System.out.println("Armstrong number");
		} else
			System.out.println("Not Armstrong number");
		sc.close();
	}

}

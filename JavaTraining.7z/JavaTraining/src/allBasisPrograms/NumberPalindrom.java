package allBasisPrograms;

import java.util.Scanner;

public class NumberPalindrom {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);

		int num = sc.nextInt(), reamainder, reverseNum = 0;
		int checkNum = num;
		while (checkNum != 0) {
			reamainder = checkNum % 10;

			reverseNum = reverseNum * 10 + reamainder;
			checkNum = checkNum / 10;
		}
		if (num == reverseNum) {
			System.out.println("Palindrome");
		} else {
			System.out.println("not a palindrome");
		}

	}

}

package allBasisPrograms;

import java.util.Scanner;

public class SwapVariable {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		int a, b;
		System.out.println("Enter variable a:");
		a = sc.nextInt();
		System.out.println("Enter variable b:");

		b = sc.nextInt();

		a = a + b;

		b = a - b;

		a = a - b;

		System.out.println("a = " + a + " b = " + b);
		
sc.close();
	}

}

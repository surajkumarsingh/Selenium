package allBasisPrograms;

import java.util.Scanner;

public class StringPalindrome {

	public static void main(String[] args) {

		Scanner sc = new Scanner(System.in);
		String pali, check = "";

		pali = sc.nextLine();

		for (int j = pali.length() - 1; j >= 0; j--) {

			check = check + pali.charAt(j);
		}
		if (pali.equals(check)) {
			System.out.println(pali + " is palindrome");
		} else {
			System.out.println(pali + " not a plaindrome");
		}
sc.close();
	}

}

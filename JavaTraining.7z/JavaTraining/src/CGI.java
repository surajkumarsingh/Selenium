public class CGI {

	public static void main(String[] args) {
		CGI obj = new CGI();
		obj.print(2, 3);
	}

	public void print(int start, int n) {
		
		for (int i = 0; i < n; i++) {
		int j= start;
			for (int k = start; k <= n - 1; k++) {

				System.out.print(j);
		
			}
			++start;
			System.out.println();
		
		}
	}
}


public class Main {
public static void main(String[] args) {
	System.out.println("class 1");
}
}
class Class2{
	public static void main(String[] args) {
		System.out.println("Class 2");
	}
}

class Class3{
	
	public static void main(String[] args) {
		System.out.println("class 3");
	}
}
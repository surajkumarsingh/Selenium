package contructors;

class Overrider extends ConstructorOverriding{
	
public static void main(String[] args) {
	Overrider obj = new Overrider();
	obj.i = 8;
	System.out.println(obj.i);
	
}
}
package contructors;

public class ParaDefault {
	static int x;
	int y=0;

	/* ParaDefault(){
		int  x = 0;
		int y = 0;
		}*/
	 ParaDefault(int x, int y){
		 this.x=x;
		 this.y=y;
	 }
	public static void main(String[] args) {
		// ParaDefault ref = new  ParaDefault();
		// ParaDefault ref2 = new  ParaDefault(4,7);
		// System.out.println(ref2.y);
		 System.out.println(x);

	}

}

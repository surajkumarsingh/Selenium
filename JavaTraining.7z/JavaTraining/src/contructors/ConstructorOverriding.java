package contructors;

public class ConstructorOverriding {

	int i = 9;	
}



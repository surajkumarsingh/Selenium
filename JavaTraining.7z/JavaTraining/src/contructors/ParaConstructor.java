package contructors;

public class ParaConstructor {
public static void main(String[] args) {
	Rectangle r1= new Rectangle();
	r1.setLength(20.0f);
	r1.setBreadth(10.0f);
	System.out.println(r1.getArea());
	System.out.println(r1.getBreadth());
}
}
class Rectangle{
	float length;
	float breadth;
	public float getLength() {
		return length;
		} 
	public void setBreadth(float breadth) {
		this.breadth=breadth;
	}
	public void setLength(float length) {
		this.length=length;
	}
	
	public float getBreadth() {
	return breadth;}
	
public float getArea() {
return length*breadth;	}
}


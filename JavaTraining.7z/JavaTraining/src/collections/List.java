package collections;


import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;    
class TestArrayLinked{    
 public static void main(String args[]){    
     
  List<String> al=new ArrayList<String>();//creating arraylist    
  al.add("3");//adding object in arraylist    
  al.add("Vijay");    
  al.add("Ravi");    
  al.add("9"); 
  al.remove("Ravi");
    
  List<String> al2=new LinkedList<String>();//creating linkedlist    
  al2.add("James");//adding object in linkedlist    
  al2.add("Serena");    
  al2.add("Swati");    
  al2.add("Junaid");    
    
  System.out.println("arraylist: "+al.get(1)+al.remove(al.get(1))+al.remove(al.get(1)));  
  System.out.println("linkedlist: "+al2.get(2));  
 }    
}    
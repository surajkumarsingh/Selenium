package collections;

import java.util.*;

public class ArrayLis {
	public static void main(String args[]) {
		ArrayList<String> list = new ArrayList<String>();// Creating array list
		list.add("kavi");// Adding object in array list
		list.add("Vijay");
		list.add("Ravi");
		list.add("Ajay");
		System.out.println(list);
	//	System.out.println(list.get(6));
		// Traversing list through Iterator
		/*Iterator<String> itr = list.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
			}*/
		//list.clear();
		/*for (String a : list) {// #by for each loop
			System.out.println(a);
		}*/
		
		System.out.println(list.get(2));
list.clear();	}
}

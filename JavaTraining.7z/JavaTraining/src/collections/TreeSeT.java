package collections;
import java.util.*;
public class TreeSeT {

	public static void main(String[] args) {
	
	
		TreeSet<Object> ts = new TreeSet<Object>();
		ts.add(null);
	//	ts.add(7);
	//	ts.add(null);
/*		
		ts.add("1");
		ts.add("9");
		ts.add("8")*/;
		
System.out.println(ts);
	}

}

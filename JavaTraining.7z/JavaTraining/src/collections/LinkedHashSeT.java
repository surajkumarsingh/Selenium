package collections;
import java.util.*;
public class LinkedHashSeT {
public static void main(String[] args) {
	

	LinkedHashSet<String> ls = new LinkedHashSet<String>();
	
	ls.add("suraj");
	ls.add("kumar");
	//ls.add();
	
	System.out.println(ls);
}
}
package collections;
import java.util.*;
public class HashTable {
	
public static void main(String[] args) {
	Hashtable<Integer, String> ht = new Hashtable<Integer, String>();
	
	ht.put(99, "A");
	ht.put(2, "B");
	ht.put(5,"E");
	ht.put(0,"C");
	System.out.println(ht);
}	
	
	

}

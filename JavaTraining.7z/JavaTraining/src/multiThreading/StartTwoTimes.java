package multiThreading;

public class StartTwoTimes extends Thread {
	public static void main(String[] args) {// main thread started
		StartTwoTimes t = new StartTwoTimes(); // MyThread is created
		t.start();
		t.start();
	}

}

package multiThreading;

public class Test extends Thread{

	public static void main(String[] args) {
		Test t = new Test();
		t.run();
		for (int i=0;i<5;i++ )
		{ System.out.println("main thread");
	}

}}

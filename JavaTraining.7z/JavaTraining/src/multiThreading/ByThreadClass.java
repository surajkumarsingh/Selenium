package multiThreading;

public class ByThreadClass extends Thread {
	
	// defining a Thread
	// business logic of user defined Thread
	public void run() {
		for (int i = 0; i < 10; i++) {
			System.out.println("userdefined Thread");
		}
	}
}

class ThreadDem {
	public static void main(String[] args) // main thread started
	{
		ByThreadClass t = new ByThreadClass(); // MyThread is created
		t.start(); // ByThreadClass execution started
		/***
		 * first it goes for Main method and then start for run()
		 ***/
		// business logic of main Thread
		for (int i = 0; i < 10; i++) {
			System.out.println("Main Thread");
		}
	}
}

package multiThreading;

public class TestJoin extends Thread {
	int i;

	public void run() {
		for (i = 0; i <= 5; i++) {
			try {
				Thread.sleep(2);
			} catch (Exception e) {
				System.out.println(e);
			}
			System.out.println(i);
		}

	}

	public static void main(String[] args) {
		TestJoin t1 = new TestJoin();
		TestJoin t2 = new TestJoin();
		TestJoin t3 = new TestJoin();
		t1.start();
		try {
			t1.join();
		} catch (InterruptedException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		t2.start();
		t3.start();
	}
}

package multiThreading;

public class OverrideStart extends Thread {
	
	public	void start()
{ System.out.println("override start method");
}
	public	void run() {System.out.println("run Method");}
}
	class ThreadD {
		public static void main(String[] args) {
			OverrideStart t = new OverrideStart();
			OverrideStart t1 = new OverrideStart();
			t.start();
			t1.start();
			System.out.println(t.getName());
			System.out.println(t1.getName());
			for (int i = 0; i < 5; i++) {
				System.out.println("main thread");
			}
		}
	}

	



package multiThreading;

public class ThreadDemo extends Thread {
	public static void main(String[] args) {
		//Step 2:-Create user defined Thread class object.
		Thread t=Thread.currentThread();
		Thread t2=Thread.currentThread();
		System.out.println(t);
		System.out.println(t2);
		ThreadDemo t1=new ThreadDemo();
		//Step 3:-Start the Thread by using start() method of Thread class.
		t1.start();
		
	}
	public void run()
	{ 	Thread t=Thread.currentThread();
	System.out.println(t);
		System.out.println("business logic of the thread");
	System.out.println("body of the thread");
	
	}
	
	
}

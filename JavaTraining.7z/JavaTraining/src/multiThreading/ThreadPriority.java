package multiThreading;

public class ThreadPriority extends Thread {
	public void run() {
		System.out.println("current Thread priority = " + Thread.currentThread().getPriority());
		System.out.println("current Thread name = " + Thread.currentThread().getName());
		
	}
};

class ThreadDemoo {
	public static void main(String[] args)// main thread started
	{
		ThreadPriority t1 = new ThreadPriority();
		t1.setPriority(Thread.MAX_PRIORITY);
		ThreadPriority t2 = new ThreadPriority();
		t2.setPriority(Thread.MIN_PRIORITY);
	
		t2.start();
		t1.start();
		
	}
}

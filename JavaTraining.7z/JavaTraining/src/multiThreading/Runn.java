package multiThreading;

public class Runn implements Runnable {

	public void run() { // business logic of user defined Thread
		for (int i = 0; i < 10; i++) {
			System.out.println("userdefined Thread");
		}
	}
}

class ThreadDe {
	public static void main(String[] args) // main thread started
	{
		Runn r = new Runn(); // MyThread is created
		Thread t = new Thread(r);
		t.start(); // MyThread execution started
		// business logic of main Thread
		for (int i = 0; i < 10; i++) {
			System.out.println("Main Thread");
		}
	}
}
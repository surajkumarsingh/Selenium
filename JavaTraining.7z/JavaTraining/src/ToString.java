
public class ToString {

	public static void main(String[] args) {

		ToString t = new ToString();
		
		System.out.println(t);
		String s = t.toString();
		System.out.println(s);

	}

}

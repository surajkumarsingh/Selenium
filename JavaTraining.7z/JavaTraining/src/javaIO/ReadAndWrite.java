package javaIO;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FilterInputStream;
import java.io.IOException;

public class ReadAndWrite {

	public static void main(String[] args) throws IOException {
		FileInputStream fin = new FileInputStream("suraj.txt");
		FileOutputStream fos = new FileOutputStream("Output.txt");
		int c;
		
		while ((c=fin.read())!=-1) {
			System.out.println((char)c);
			fos.write(c);
		}
		
		
	}

}

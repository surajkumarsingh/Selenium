package javaIO;
import java.io.*;
public class Directory {
	public static void main(String[] args) throws IOException { // creation of File
		File f = new File("suraj.txt");
		System.out.println(f.exists());
		f.createNewFile();
		System.out.println(f.exists());
		// creation of directory
		File f1 = new File("suraj");
		System.out.println(f1.exists());
		f1.mkdir();
		System.out.println(f1.exists());
		// creation of file inside the directory (directory must present)
		File f2 = new File("suraj", "suraj.txt");
		System.out.println(f2.exists());
		f2.createNewFile();
	}

}

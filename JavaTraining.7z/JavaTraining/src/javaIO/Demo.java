package javaIO;

import java.io.*;

public class Demo {
	public static void main(String[] args) throws IOException {
		System.out.println("output stream");
		System.err.println("error stream");

		/*int a = System.in.read();
		System.out.println((char) a);*/
	}
}

package pattern;

public class pattern1 {

	public static void main(String[] args) {
		char temp=97;
		
		for(int i=1;i<5;i++)
		{

		for(int j=1;j<=i;j++)
		{
		System.out.print("_");
		}

		for(int k=1;k<=i;k++)
		{
		System.out.print(temp);
		}
		System.out.println();
		temp++;
		}

	}

}

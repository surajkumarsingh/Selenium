package pattern;

public class Pattern_abc {

	public static void main(String[] args) {
		/*for( int i=0; i<4; i++) {
	if(i==0) {
		System.out.print("_a");}
		else if(i==1) {
			System.out.print("__bb");

		}
		else if(i==2) {
			System.out.print("__ccc"); 
	}

		else if(i==3) {
			System.out.print("___dddd");
		}
	System.out.println();}*/
		char temp=97;


		for(int a=0; a<4; a++) 
		{
			for(int b=0; b<=a; b++) {
				 

					System.out.print("_");
				}
				 for(int c=0; c<=a;c++) {
				System.out.print(temp);

			}



			System.out.println();
			++temp;

		}



	}
}
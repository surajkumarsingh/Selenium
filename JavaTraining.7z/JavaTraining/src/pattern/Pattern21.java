package pattern;

public class Pattern21 {

	public static void main(String[] args) {
		int a=1;
	   for(int i=0; i<4;i++) {
		 for(int j=0;j<=i;j++) {
			 if(j>=1) {
				 System.out.print("*");
			 }
			 System.out.print(a);
			
		 }
	  System.out.println();
	 ++a; }}
}
	
	



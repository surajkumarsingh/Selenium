package pattern;

public class Pattern40 {

	public static void main(String[] args) {
		int i=4;
		for(int j=0;j<5; j++) {
			for(int a=4; a>j; a--) {
			System.out.print(i);
			System.out.print(0);
			
		}--i;
System.out.println();
	}

}
}
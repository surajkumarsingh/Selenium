package pattern;

public class Pattern2 {

	public static void main(String[] args) {
		
		for(int j=0; j<4; j++) {
			int i=10;
			for(int a=0;a<=j; a++) {
	System.out.print(i);
for(int b=1;b<=a; a++) {
System.out.print("*");	}
}

			System.out.println();
			
			}
	}
}
package pattern;

public class PatternStar12 {

	public static void main(String[] args) {
	int a=1; int c=1;
	for(int i=1; i<=4; i++) {
		for(int j=1;j<=i;j++) {
		if(j>=2) {
			System.out.print("*");
			System.out.print(c+a);
			++a;
		}else {System.out.print(a);
		
			
		}
			}
		++a;
System.out.println();	}

}
}
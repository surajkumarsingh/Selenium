package pattern;
import java.util.Scanner;
public class Aysh_Pattern {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		for(int j=0; j<4; j++) {
			for(int i=0; i<4; i++) {
				if(j==1 && i==2) {
					System.out.print(1+""+a+""+a);
					}else if(j==2 && i==2){
						System.out.print(2);}
				System.out.print(a);
			}
				
				
				System.out.println();
		}

	sc.close();}

}

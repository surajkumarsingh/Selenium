package pattern;
import java.util.*;
public class HackR {
	 // Complete the solve function below.
    static void solve(double meal_cost, double tip_percent, double tax_percent) {   
  double tip=(tip_percent/100)*meal_cost;
 double tax=(tax_percent/100)*meal_cost;
        double i=meal_cost+tip+tax;
        int j= (int) Math.round(i);

    System.out.println("The total meal cost is "+j+" dollars.");
    }
    private static final Scanner scanner = new Scanner(System.in);
    public static void main(String[] args) {
        double meal_cost = scanner.nextDouble();
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");
        double tip_percent = scanner.nextDouble();
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");
        double tax_percent = scanner.nextDouble();
        scanner.skip("(\r\n|[\n\r\u2028\u2029\u0085])?");
        solve(meal_cost, tip_percent, tax_percent);
        scanner.close();
    }
}




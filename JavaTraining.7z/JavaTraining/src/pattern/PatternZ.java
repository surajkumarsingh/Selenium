package pattern;

public class PatternZ {
	public static void main(String[] args) {
		char a=90;
		for(int i=0; i<=4;i++) {
			for(int j=4;j>=i;j--) {
				System.out.print(a);
			}
	System.out.println();	
	--a;}
}}

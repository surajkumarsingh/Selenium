package pattern;

public class PatternX {

	public static void main(String[] args) {
		// TODO Auto-generated method stu
			
}
	

}

package pageFactory;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import io.appium.java_client.pagefactory.AndroidFindBy;
import io.appium.java_client.pagefactory.AppiumFieldDecorator;
import testBase.TestBase;
/**
 * 
 * @author suraj_kumar
 *
 */

public class CalculatorFactory extends TestBase {

	public CalculatorFactory() {

		PageFactory.initElements(new AppiumFieldDecorator(driver), this);
	}

	@AndroidFindBy(id = "com.android.calculator2:id/digit_0")
	public WebElement num0;
	
	@AndroidFindBy(id = "com.android.calculator2:id/digit_1")
	public WebElement num1;

	@AndroidFindBy(id = "com.android.calculator2:id/digit_2")
	public WebElement num2;

	@AndroidFindBy(id = "com.android.calculator2:id/digit_3")
	public WebElement num3;

	@AndroidFindBy(id = "com.android.calculator2:id/digit_4")
	public WebElement num4;

	@AndroidFindBy(id = "com.android.calculator2:id/digit_5")
	public WebElement num5;

	@AndroidFindBy(id = "com.android.calculator2:id/digit_6")
	public WebElement num6;

	@AndroidFindBy(id = "com.android.calculator2:id/digit_7")
	public WebElement num7;

	@AndroidFindBy(id = "com.android.calculator2:id/digit_8")
	public WebElement num8;

	@AndroidFindBy(id = "com.android.calculator2:id/digit_9")
	public WebElement num9;

	@AndroidFindBy(id = "com.android.calculator2:id/op_sub")
	public WebElement subs;

	@FindBy(id = "com.android.calculator2:id/op_mul")
	public WebElement mul;

	@AndroidFindBy(id = "com.android.calculator2:id/op_div")
	public WebElement div;

	@AndroidFindBy(id = "com.android.calculator2:id/op_add")
	public WebElement add;

	@AndroidFindBy(id = "com.android.calculator2:id/eq")
	public WebElement eq;

	@AndroidFindBy(id = "com.android.calculator2:id/result")
	public WebElement result;

/**
 * click on number "9"
 */
	public void num9() {
		num9.click();
	}
	/**
	 * click on  number"1"
	 */
	public void num1() {
		num1.click();
	}
	/**
	 * click on number "2"
	 */
	public void num2() {
		num2.click();
	}
	/**
	 * click on number "3"
	 */
	public void num3() {
		num3.click();
	}
	/**
	 * click on number "4"
	 */
	public void num4() {
		num4.click();
	}
	/**
	 * click on number "5"
	 */
	public void num5() {
		num5.click();
	}
	/**
	 * click on number "6"
	 */
	public void num6() {
		num6.click();
	}
	/**
	 * click on number "7"
	 */
	public void num7() {
		num7.click();
	}
	/**
	 * click on number "8"
	 */
	public void num8() {
		num8.click();
	}
	/**
	 * click on number "0"
	 */
	public void num0() {
		num0.click();
	}
	/**
	 * click on "+"
	 */
	public void add() {
		add.click();
	}
	/**
	 * click on "x"
	 */
	public void multi() {
		mul.click();
	}
	/**
	 * click on "-"
	 */
	public void sub() {
		subs.click();
	}
	/**
	 * click on "/"
	 */
	public void div() {
		div.click();
	}
	/**
	 * click on "="
	 */
	public void eq() {
		eq.click();
	}
	/**
	 * Give the result
	 * @return String
	 */
	public String result() {
		return result.getText();
	}
}

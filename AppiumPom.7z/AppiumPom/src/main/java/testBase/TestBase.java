package testBase;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.touch.offset.PointOption;

public class TestBase {

	public static AppiumDriver<AndroidElement> driver;
	public static	PointOption point;
	public TouchAction touch;
	public static MobileElement mobileElement;
	    //protected WebDriverWait wait;
	   //Constructor
	   /* public TestBase(AndroidDriver<AndroidElement> driver) {
	      driver = TestBase.driver;
	        mobileActions = new TouchActions(driver); //We are using MobileActions with this instance. Composition.
	       // wait = new WebDriverWait(driver, 20);
	    }*/
	
	public static void initialization() throws MalformedURLException {
		 DesiredCapabilities capabilities = new DesiredCapabilities();
		    capabilities.setCapability("platformName", "Android");
		    capabilities.setCapability("platformVersion", "7.0");
		    capabilities.setCapability("deviceName", "emulator-5554");
		    capabilities.setCapability("appPackage", "com.android.calculator2");
		    capabilities.setCapability("appActivity", "com.android.calculator2.Calculator");
		    driver =  new AndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"),
				capabilities);

	}
}

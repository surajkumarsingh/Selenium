package com.smokeTest;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.touch.ScrollAction;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import android.webkit.WebView;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.touch.offset.PointOption;
import testBase.TestBase;

public class OutLook extends TestBase {

	DesiredCapabilities capabilities = new DesiredCapabilities();
	WebElement element;

	@BeforeMethod
	public void setup() throws MalformedURLException {

		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "7.0");
		capabilities.setCapability("deviceName", "emulator-5554");
		capabilities.setCapability("appPackage", "com.microsoft.office.outlook");
		capabilities.setCapability("noReset", "true");
		// capabilities.setCapability("autoDismissAlerts", true);
		capabilities.setCapability("appActivity", "com.microsoft.office.outlook.MainActivity");
		driver = new AndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
	}

	@Test
	public void checkAccount() throws InterruptedException {
		driver.findElement(By.xpath("//android.widget.ImageButton[@content-desc='Compose']")).click();
		Thread.sleep(5000);
		driver.findElement(By.xpath(
				"//android.widget.MultiAutoCompleteTextView[@resource-id='com.microsoft.office.outlook:id/compose_to_field']"))
				.sendKeys("surajkumar100395@gmail.com");

		driver.findElement(By.xpath("//android.widget.EditText[@text='Subject']")).sendKeys("Test");

		driver.findElement(By.id("com.microsoft.office.outlook:id/compose_body")).clear();
		driver.findElement(By.id("com.microsoft.office.outlook:id/compose_body"))
				.sendKeys("hi suraj //n this the test.");

//Identify an element using Resource ID (exact match)
//MobileElement searchBox =(MobileElement) driver.findElementByClassName("new UiSelector().className(\"com.microsoft.office.outlook:id/compose_body\")");
//searchBox.sendKeys("suraj kumar");

//		UiObject cancelButton = device.findObject(new UiSelector()
//		        .text("Cancel")
//		        .className("android.widget.Button"));
//		MobileElement element = (MobileElement) driver.findElement(MobileBy.AndroidUIAutomator(	 "new UiSelector().className(\"	com.acompli.acompli.views.TriggeredAutoCompleteTextView\"), \"Get Outlook for Android\")"));
//				element.sendKeys("ghhj");
//				+ "new UiSelector().className(\"android.widget.TextView\"), \"Games We Are Playing\")"));
		/*
		 * MobileElement element = (MobileElement)
		 * driver.findElement(MobileBy.AndroidUIAutomator(
		 * "new UiClickable(new UiSelector().resourceId(\"com.microsoft.office.outlook:id/compose_body\")).("
		 * + "new UiSelector().description(\"Get Outlook for Android\"))"));
		 * element.sendKeys("trial");
		 */

		// driver.findElement(By.id("//com.microsoft.office.outlook:id/compose_body")).sendKeys("Trial");

		driver.findElement(By.xpath("//android.widget.TextView[@content-desc='Send']")).click();

		// driver.manage().timeouts().implicitlyWait(2, TimeUnit.SECONDS);
		// Thread.sleep(8000);

		try {
			WebDriverWait wait = new WebDriverWait(driver, 30);
			// mobileElement = (MobileElement)
			// driver.findElement(By.xpath("//android.widget.TextView[@text='Test']"));
			wait.until(
					ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.TextView[@text='Test']")));

			WebElement subject = driver.findElement(By.xpath("//android.widget.TextView[@text='Test']"));

			Assert.assertEquals(subject.getText(), "Test");

			// System.out.println(subject.getText());

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		PointOption start = point.point(130,784);
//		//PointOption end = point.point(0,1470);
//		touch = new TouchAction(driver);
//		
//		touch.press(start).release().perform();

		// System.out.println(msg);

		// driver.findElement(By.xpath("//android.widget.MultiAutoCompleteTextView[@text='Cc/Bcc'")).sendKeys("");
		// click By coordinates
//		touch = new TouchAction(driver);
//		PointOption cmail = point.point(947,1475);
//		touch.tap(cmail).release().perform();
	}

}

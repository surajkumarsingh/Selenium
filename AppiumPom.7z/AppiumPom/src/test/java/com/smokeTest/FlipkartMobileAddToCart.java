package com.smokeTest;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import testBase.TestBase;

public class FlipkartMobileAddToCart extends TestBase {
	DesiredCapabilities capabilities = new DesiredCapabilities(); 

	@BeforeMethod
	public void setup() throws MalformedURLException, InterruptedException {
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "7.0");
		capabilities.setCapability("deviceName", "emulator-5554");
		capabilities.setCapability("appPackage", "com.flipkart.android");
		capabilities.setCapability("noReset", "true");
		
		// capabilities.setCapability("autoDismissAlerts", true);
		capabilities.setCapability("appActivity", "com.flipkart.android.SplashActivity");
		driver = new AndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
		Thread.sleep(5000);
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	@Test
	
	public void addToCartMobile() throws InterruptedException {
		//Thread.sleep(5000);
		//try {
//			WebDriverWait wait = new WebDriverWait(driver, 30);
//			//mobileElement = (MobileElement) driver.findElement(By.xpath("//android.widget.TextView[@text='Test']"));
//			wait.until(ExpectedConditions.visibilityOfElementLocated(By.xpath("//android.widget.LinearLayout[@content-desc=\"Search on flipkart\"]/android.widget.TextView")));
		
			WebElement subject =driver.findElement(By.xpath("//android.widget.LinearLayout[@content-desc='Search on flipkart']/android.widget.TextView"));	
		subject.click();
		driver.findElement(By.xpath("//android.widget.EditText[@content-desc='Search grocery products in Supermart']")).sendKeys("Moto power");
		Thread.sleep(5000);
		driver.findElement(By.xpath("//android.widget.RelativeLayout[@instance=1]")).click();	
		//driver.findElement(By.xpath("//android.widget.Button[@text='NOT NOW']")).click();	
		driver.findElement(By.xpath("//android.widget.TextView[@text='Motorola One Power (Black, 64 GB)']")).click();	
		driver.findElement(By.xpath("//android.widget.TextView[@text='ADD TO CART']")).click();	
		
		
		
//		Assert.assertEquals(subject.getText(), "Test");
//			Assert.assertEquals(subject.getText(), "Test");
		
			//System.out.println(subject.getText());
			
			
//		} catch (Exception e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
		
		
		
//		MobileElement topCharts = ((AndroidDriver<AndroidElement>)driver).findElementByAndroidUIAutomator("new UiSelector().resourceId(\"com.flipkart.android:id/search_widget_textbox\")");
//		topCharts.click();
		//Perform the required action on the element
	//	driver.findElement(By.xpath("//android.widget.LinearLayout[@content-desc='Search on flipkart']/android.widget.TextView")).click();
		//driver.findElement(By.xpath("//android.widget.TextView[@instance=0]")).click();
	}
}

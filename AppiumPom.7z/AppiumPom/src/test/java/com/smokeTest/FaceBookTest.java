package com.smokeTest;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.NoSuchElementException;
import java.util.concurrent.TimeUnit;

import android.view.View;
import android.webkit.WebView;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.*;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.TouchAction;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.touch.offset.PointOption;
import testBase.TestBase;

public class FaceBookTest extends TestBase {

	DesiredCapabilities capabilities = new DesiredCapabilities();
    WebView mviews;
	WebElement element;
	ChromeOptions options=new ChromeOptions();
	

	
	@BeforeMethod
	public void setup() throws MalformedURLException {
		
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "7.0");
		capabilities.setCapability("deviceName", "emulator-5554");
		capabilities.setCapability("appPackage", "com.android.chrome");
		capabilities.setCapability("noReset", "true");
		capabilities.setCapability("autoDismissAlerts", true);
		
		//options.setExperimentalOption("androidPackage", "com.android.chrome");
	//	capabilities.setCapability(ChromeOptions.CAPABILITY, options);
		//capabilities.setCapability(ChromeOptions.CAPABILITY, "--disable-popup-blocking");
    	//chromeOptions: {args: ['--disable-popup-blocking']}
		 
		capabilities.setCapability("appActivity", "com.google.android.apps.chrome.Main"); // This is Launcher activity
		driver = new AndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
	/*	WebDriver wb = new AppiumDriver<WebElement>(capabilities);
		 options.addArguments("--disable-notifications");
		     System.setProperty("webdriver.chrome.driver", "D:\\Suraj_WorkSpace\\AppiumPom\\chromedriver.exe");
		        wb= new AppiumDriver<WebElement>(options);*/
//		
	driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
//		driver.get("https://m.facebook.com");
//		driver.findElement(By.id("m_login_email")).sendKeys("07903223869");
//		driver.findElement(By.id("m_login_password")).sendKeys("AppiumTest");
//		driver.findElement(By.id("u_0_6")).click();
//		
//		driver.findElement(By.xpath("//android.widget.Button[@index=5]")).click();	
//		
		//driver.findElement(By.id("android:id/button2")).click();
		
   
	}

	@Test
	public void fbPost() throws InterruptedException {
			
	
		driver.findElement(By.xpath("//android.widget.EditText[@index=1]")).click();
	
		driver.findElement(By.id("uniqid_1")).sendKeys("This is Appium Test7!");
		
		driver.findElement(By.xpath("//android.widget.Button[@index=11]")).click();
		driver.findElement(By.xpath("//android.view.View[@text='Feeling...']")).click();
		driver.findElement(By.xpath("//android.view.View[@text='happy']")).click();
		driver.findElement(By.xpath("//android.widget.Button[@text='Post']")).click();
	driver.findElement(By.xpath("//android.view.View[@text='Open story']")).click();
	String post  = driver.findElement(By.xpath("//android.view.View[@text='This is Appium Test7!']")).getText();
	Assert.assertEquals(post, "This is Appium Test7!");
System.out.println(post);
	}

	@Test
	
	public void fblogOut() throws InterruptedException {
	
		driver.findElement(By.xpath("//	android.widget.Button[@text='Main Menu']")).click();
		Thread.sleep(5000);
		PointOption start = point.point(0,378);
		PointOption end = point.point(0,1470);
		touch = new TouchAction(driver);
		touch.press(end).moveTo(start).release().perform();
		
		
		
		
		
		
		
		
//	WebElement start = driver.findElement(By.xpath("//android.view.View[@text='Appium Text']"));	
//	//WebElement	logout = driver.findElement(By.xpath("//android.view.View[@text='Log Out']"));	
//	
//	WebElement logout =	driver.findElement(MobileBy.AndroidUIAutomator(
//  				"new UiScrollable(new UiSelector().resourceId(\"u_b_1\")).getChildByText("
//  				+ "new UiSelector().className(\"android.view.View\"), \"Log Out\")"));	
//		logout.click();
		driver.findElement(By.xpath("//android.view.View[@text='Log Out']")).click();
	}
	
/*	@AfterTest
	public void tearDown() {
		driver.quit();}
	*/
}
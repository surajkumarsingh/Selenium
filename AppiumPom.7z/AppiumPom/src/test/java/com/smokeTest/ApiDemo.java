package com.smokeTest;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.touch.TouchActions;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileBy;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;
import io.appium.java_client.android.AndroidElement;
import io.appium.java_client.android.AndroidKeyCode;
import io.appium.java_client.android.nativekey.AndroidKey;
import io.appium.java_client.android.nativekey.KeyEvent;
import io.appium.java_client.touch.TapOptions;
import io.appium.java_client.touch.offset.PointOption;
import testBase.TestBase;
import io.appium.java_client.TouchAction;

public class ApiDemo extends TestBase {

	DesiredCapabilities capabilities = new DesiredCapabilities();
	TouchAction tc;
	 WebElement element;

	public ApiDemo() {
		super();
		// TODO Auto-generated constructor stub
	}

	@BeforeMethod

	public void setup() throws MalformedURLException {
		// Set up desired capabilities and pass the Android app-activity and app-package
		// to Appium

		// TouchAction Action = new TouchAction(driver)

		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "7.0");
		capabilities.setCapability("deviceName", "emulator-5556");
		capabilities.setCapability("appPackage", "com.example.android.apis");
		// This package name of your app (you can get it from apk info app)

	}

	@Test
	public void buttons() throws MalformedURLException {

		// capabilities.setCapability("appActivity",
		// "com.example.android.apis.view.Buttons1"); // This is Launcher activity of
		// your app
		driver = new AndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
		MobileElement element = (MobileElement) driver.findElement(MobileBy.AndroidUIAutomator(
				"new UiScrollable(new UiSelector().resourceId(\"com.android.vending:id/data_view\")).scrollIntoView("
						+ "new UiSelector().text(\"Views\"))"));

		// driver.findElement(By.id("com.example.android.apis:id/button_normal")).click();
		/*
		 * boolean b =
		 * driver.findElement(By.id("com.example.android.apis:id/button_normal")).
		 * isDisplayed(); Assert.assertEquals(b, true);
		 * 
		 * driver.findElement(By.id("com.example.android.apis:id/button_toggle")).click(
		 * ); String on =
		 * driver.findElement(By.id("com.example.android.apis:id/button_toggle")).
		 * getText(); Assert.assertEquals(on, "ON");
		 */
	}

	@Test
	public void tab1Switch() throws MalformedURLException {
		capabilities.setCapability("appActivity", "com.example.android.apis.view.Tabs1"); // This is Launcher activity
																							// of your app
		driver = new AndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
		driver.findElement(By.xpath("//android.widget.LinearLayout[@index=0]")).click();
		String res = driver.findElement(By.xpath("//android.widget.TextView[@text='tab1']")).getText();
		Assert.assertEquals(res, "tab1", "Result didn't matched");
		driver.findElement(By.xpath("//android.widget.LinearLayout[@index=1]")).click();
		res = driver.findElement(By.xpath("//android.widget.TextView[@text='tab2']")).getText();
		Assert.assertEquals(res, "tab2", "Result didn't matched");
		driver.findElement(By.xpath("//android.widget.LinearLayout[@index=2]")).click();
		res = driver.findElement(By.xpath("//android.widget.TextView[@text='tab3']")).getText();
		Assert.assertEquals(res, "tab3", "Result didn't matched");
	}

	@Test
	public void scrollableTabs() throws MalformedURLException {

		capabilities.setCapability("appActivity", "com.example.android.apis.ApiDemos"); // This is Launcher activity of
																						// your app
		driver = new AndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
	
      List<AndroidElement> vi = driver.findElements(By.xpath("//android.widget.TextView[@text]"));
      for (int i = 0; i <= vi.size() - 1; i++) {
    	  			if (vi.get(i).getText() == "Views") {
    	              vi.get(i).click();}
    	              else {
    	            	  element =  driver.findElement(MobileBy.AndroidUIAutomator(
    	    	      				"new UiScrollable(new UiSelector().resourceId(\"android:id/list\")).getChildByText("
    	    	      				+ "new UiSelector().className(\"android.widget.TextView\"), \"Views\")"));	
    	            	  element.click();
    	            	  break;
    	            	  }
    	              }
    	        element =  driver.findElement(MobileBy.AndroidUIAutomator(
    	      				"new UiScrollable(new UiSelector().resourceId(\"android:id/list\")).getChildByText("
    	      				+ "new UiSelector().className(\"android.widget.TextView\"), \"Tabs\")"));	
    	        element.click();

		driver.findElement(By.xpath("//android.widget.TextView[@index=4]")).click();
		element = driver.findElement(MobileBy.AndroidUIAutomator(
				"new UiScrollable(new UiSelector().resourceId(\"android:id/tabs\")).setAsHorizontalList().scrollIntoView("
				+ "new UiSelector().text(\"TAB 23\"))"));
		element.click();
    	  			
	}

	/*
	 * @Test public void tab2Switch() throws MalformedURLException {
	 * capabilities.setCapability("appActivity",
	 * "com.example.android.apis.view.Tabs1"); // This is Launcher activity of your
	 * app driver = new AndroidDriver<MobileElement>(new
	 * URL("http://0.0.0.0:4723/wd/hub"), capabilities); }
	 */
	@Test
	public void controls() throws MalformedURLException {
		capabilities.setCapability("appActivity", "com.example.android.apis.view.Controls1"); // This is Launcher
																								// activity of your app
		driver = new AndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"), capabilities);
		driver.findElement(By.xpath("//android.widget.Button[@index=0]")).click();
		driver.findElement(By.xpath("//android.widget.Button[@index=1]")).click();
		driver.findElement(By.xpath("//android.widget.EditText[@index=0]")).sendKeys("test1");
		driver.findElement(By.xpath("//android.widget.EditText[@index=1]")).sendKeys("test2");
		driver.findElement(By.xpath("//android.widget.CheckBox[@text='Checkbox 1']")).click();
		driver.findElement(By.xpath("//android.widget.CheckBox[@text='Checkbox 2']")).click();
		driver.findElement(By.id("com.example.android.apis:id/radio1")).click();

		driver.findElement(By.id("com.example.android.apis:id/toggle1")).click();
		driver.findElement(By.id("com.example.android.apis:id/toggle2")).click();
		driver.findElement(By.id("com.example.android.apis:id/spinner1")).click();
		driver.findElement(By.xpath("//android.widget.CheckedTextView[@text='Earth']")).click();

	}

	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}

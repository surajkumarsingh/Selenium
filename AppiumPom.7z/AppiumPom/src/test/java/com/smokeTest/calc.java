package com.smokeTest;

import java.net.MalformedURLException;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


import pageFactory.CalculatorFactory;
import testBase.TestBase;

public class calc extends TestBase {
	CalculatorFactory cal;

	public calc() {
		super();
	}

	@BeforeMethod
	public void setup() throws MalformedURLException {
		initialization();
	}

	@Test
	public void addition() throws MalformedURLException {
		cal = new CalculatorFactory();
		cal.num3();
		cal.add();
		cal.num8();
		cal.eq();
		String res = cal.result();
		Assert.assertEquals(res, "11");

	}

	@Test
	public void multiplication() throws MalformedURLException {

		cal = new CalculatorFactory();
		cal.num8();
		cal.multi();
		cal.num8();
		cal.eq();
		String res = cal.result();
		Assert.assertEquals(res, "64");

	}

	@Test
	public void substraction() throws MalformedURLException {

		cal = new CalculatorFactory();
		cal.num8();
		cal.add();
		cal.num8();
		cal.sub();
		cal.num9();
		cal.eq();
		String res = cal.result();
		Assert.assertEquals(res, "7");

	}
	@Test
	public void division() throws MalformedURLException {

		cal = new CalculatorFactory();
		cal.num8();
		cal.multi();
		cal.num8();
		cal.div();
		cal.num9();
		cal.eq();
		String res = cal.result();
		System.out.println(res);
		Assert.assertEquals(res, "7.11111111111111111");


	}
	@AfterTest
	public void tearDown() {
		driver.quit();
	}
}

package com.smokeTest;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

import io.appium.java_client.android.AndroidDriver;
import java.net.URL;
 
public class SauceLabTest {
 
  public static final String USERNAME = "surajkumar";
  public static final String ACCESS_KEY = "35b3c0c6-7186-4dfc-807e-46bb876c4ba2";
  public static final String URL = "http://" + USERNAME + ":" + ACCESS_KEY + "@ondemand.saucelabs.com:80/wd/hub";
 
  public static void main(String[] args) throws Exception {
 
    DesiredCapabilities capabilities = new DesiredCapabilities();
    capabilities.setCapability("platformName", "Android");
   capabilities.setCapability("deviceName", "Android Emulator");
    capabilities.setCapability("platformVersion", "7.0");
  //  capabilities.setCapability("app", "http://saucelabs.com/example_files/ContactManager.apk");
    capabilities.setCapability("browserName", "chrome");
    capabilities.setCapability("deviceOrientation", "portrait");
   capabilities.setCapability("appiumVersion", "1.8.1");
 
    WebDriver driver = new RemoteWebDriver(new URL(URL), capabilities);
 
	driver.get("https://m.facebook.com");
	driver.findElement(By.id("m_login_email")).sendKeys("07903223869");
	driver.findElement(By.id("m_login_password")).sendKeys("AppiumTest");
	driver.findElement(By.id("u_0_6")).click();
	
	driver.findElement(By.xpath("//android.widget.Button[@text='Not Now']")).click();	
	
	driver.findElement(By.id("android:id/button2")).click();
	
 
    driver.quit();
  }
}
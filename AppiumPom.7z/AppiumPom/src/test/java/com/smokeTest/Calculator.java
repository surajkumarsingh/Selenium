package com.smokeTest;

import io.appium.java_client.*;
import org.openqa.selenium.remote.*;
import io.appium.java_client.android.*;
import io.appium.java_client.service.local.AppiumDriverLocalService;
import testBase.TestBase;

import java.net.*;
import org.openqa.selenium.*;
import org.testng.*;
import org.testng.annotations.*;

public class Calculator {

	public static AndroidDriver<AndroidElement> driver;
	//AppiumDriverLocalService service = AppiumDriverLocalService.buildDefaultService();
	//service.start();
	@BeforeMethod
	public void setup() throws MalformedURLException {
		//AppiumDriverLocalService service = AppiumDriverLocalService.buildDefaultService();
		//service.start();
		DesiredCapabilities capabilities = new DesiredCapabilities();
		capabilities.setCapability("platformName", "Android");
		capabilities.setCapability("platformVersion", "7.0");
		capabilities.setCapability("deviceName", "emulator-5554");
		capabilities.setCapability("appPackage", "com.android.calculator2");
		capabilities.setCapability("appActivity", "com.android.calculator2.Calculator");
		driver = (AndroidDriver<AndroidElement>) new AndroidDriver<AndroidElement>(new URL("http://0.0.0.0:4723/wd/hub"),
				(Capabilities) capabilities);
	}
	@Test
	public void addTest() {
		//service.start();
		driver.findElement(By.id("com.android.calculator2:id/digit_9")).click();
	    driver.findElement(By.id("com.android.calculator2:id/op_add")).click();
		driver.findElement(By.id("com.android.calculator2:id/digit_5")).click();
	    driver.findElement(By.id("com.android.calculator2:id/eq")).click();
		String res = driver.findElement(By.id("com.android.calculator2:id/result")).getText();
		System.out.println(res);
		Assert.assertEquals(res, "14", "Result not matched");
	}

	@Test
	public void subsTest() {
		driver.findElement(By.id("com.android.calculator2:id/digit_9")).click();
		driver.findElement(By.id("com.android.calculator2:id/op_sub")).click();
		driver.findElement(By.id("com.android.calculator2:id/digit_5")).click();
		driver.findElement(By.id("com.android.calculator2:id/eq")).click();
		String res = driver.findElement(By.id("com.android.calculator2:id/result")).getText();
		System.out.println(res);
		Assert.assertEquals(res, "4", "Result not matched");
	}

	@Test
	public void multiTest() {
		driver.findElement(By.id("com.android.calculator2:id/digit_9")).click();
		driver.findElement(By.id("com.android.calculator2:id/op_mul")).click();
		driver.findElement(By.id("com.android.calculator2:id/digit_5")).click();
		driver.findElement(By.id("com.android.calculator2:id/eq")).click();
		String res = ((MobileElement) Calculator.driver.findElement(By.id("com.android.calculator2:id/result")))
				.getText();
		System.out.println(res);
		Assert.assertEquals(res, "45", "Result not matched");
	}

	@Test
	public void divTest() {
		driver.findElement(By.id("com.android.calculator2:id/digit_5")).click();
		driver.findElement(By.id("com.android.calculator2:id/op_div")).click();
		driver.findElement(By.id("com.android.calculator2:id/digit_5")).click();
		driver.findElement(By.id("com.android.calculator2:id/eq")).click();
		String res = driver.findElement(By.id("com.android.calculator2:id/result")).getText();
		System.out.println(res);
		Assert.assertEquals(res, "1", "Result not matched");
	}
	@AfterTest
	public void tearDown() {
		driver.quit();;
	}
}
package com.QrMonkey;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

public class Qrgenerator {

	WebDriver driver;
	Actions action;
	String name = null;
	String id = null;

	@BeforeClass

	public void setup() throws InterruptedException {
		driver = new ChromeDriver();
		action = new Actions(driver);
		driver.get("https://www.qrcode-monkey.com/");
		driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
	}

	@Test
	public void enter_text() throws InterruptedException, IOException {
		File src = new File("C:\\Users\\suraj_kumar\\Documents\\QrData.xlsx");

		FileInputStream fis = new FileInputStream(src);

		XSSFWorkbook wb = new XSSFWorkbook(fis);

		XSSFSheet sheet1 = wb.getSheetAt(0);
		int row = sheet1.getLastRowNum();
		// System.out.println(row);
		Thread.sleep(15000);
		for (int i = 1; i <= row; i++) {
			name = sheet1.getRow(i).getCell(0).getStringCellValue();
			id = sheet1.getRow(i).getCell(1).getStringCellValue();
			System.out.println(name);
			System.out.println(id);
			driver.findElement(By.xpath("//a[contains(text(),'Text')]")).click();
			driver.findElement(By.xpath("//textarea[@id='qrcodeText']")).clear();
			driver.findElement(By.xpath("//textarea[@id='qrcodeText']")).sendKeys(name);
			driver.findElement(By.xpath("//textarea[@id='qrcodeText']")).sendKeys(Keys.ENTER);
			driver.findElement(By.xpath("//textarea[@id='qrcodeText']")).sendKeys(id);
			driver.findElement(By.xpath("//button[@title='Generate QR code preview']")).click();
			Thread.sleep(5000);
			driver.findElement(By.xpath("//button[contains(text(),'Download PNG')]")).click();
		}
		wb.close();
	}

}

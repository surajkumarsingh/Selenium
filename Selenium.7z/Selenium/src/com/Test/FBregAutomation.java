package com.Test;
import java.util.Scanner;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.Test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class FBregAutomation {
	@Test
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		// System.setProperty("webdriver.chrome.driver","chromedriver.exe");
	
    WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize();

		driver.get("https://facebook.com/");

		//driver.findElement(By.id("u_0_j")).sendKeys("suraj");//**1. By id : unique locator first choice
		
		//driver.findElement(By.name("firstname")).sendKeys("suraj");//**2.by name : unique locator
		String name = sc.nextLine();
		driver.findElement(By.xpath("//input[@id='u_0_j']")).sendKeys(name);//** 3.By Xpath: unique locator
		
	//	driver.findElement(By.cssSelector("#u_0_j")).sendKeys("suraj");//** 4.By Css locator
		
		//**5.linkText to test the hyperlink *provide full name of the link
	//	driver.findElement(By.linkText("Forgotten account?")).click();
		
		//**6.partiallinkText we dont't provide full name of the link ** not recommended
		//driver.findElement(By.partialLinkText("account?")).click();
		String lastName = sc.nextLine();
		driver.findElement(By.id("u_0_l")).sendKeys(lastName);
		
		//7.By class name : not unique
		//driver.findElement(By.className("inputtext _58mg _5dba _2ph-")).sendKeys("kumar");
		
		driver.findElement(By.id("u_0_o")).sendKeys("suraj931@gmail.com");
		driver.findElement(By.id("u_0_r")).sendKeys("suraj931@gmail.com");
		driver.findElement(By.id("u_0_v")).sendKeys("suraj931@gmai");
		Select dropdown = new Select(driver.findElement(By.id("day")));
		dropdown.selectByVisibleText("10");
		Select dropdown2 = new Select(driver.findElement(By.id("month")));
		dropdown2.selectByVisibleText("Jul");
		Select dropdown3 = new Select(driver.findElement(By.id("year")));
		dropdown3.selectByVisibleText("1993");
		List<WebElement> radio = driver.findElements(By.xpath("//input[@name='sex']"));
		for(int i=0; i<radio.size(); i++) {
			System.out.println(radio.get(i));
		}
		
		driver.findElement(By.id("u_0_a")).click();
		driver.findElement(By.id("u_0_11")).click();
//driver.quit();
	}

}

package com.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import java.io.File;
import java.io.FileInputStream;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class GoogleSearch {

	public static void main(String[] args) throws Exception {
		String s = null;
		WebDriver driver;
		System.setProperty("webdriver.chrome.driver", "D:\\Suraj_WorkSpace\\Selenium\\chromedriver.exe");
		File src = new File("D:\\Suraj_WorkSpace\\Selenium\\TestData\\searchData.xlsx");

		FileInputStream fis = new FileInputStream(src);

		XSSFWorkbook wb = new XSSFWorkbook(fis);

		XSSFSheet sheet1 = wb.getSheetAt(0);
		int row = sheet1.getLastRowNum();
		System.out.println(row);

		for (int i = 1; i <= row; i++) {
			s = sheet1.getRow(i).getCell(0).getStringCellValue();

			System.out.println(s);

			 driver = new ChromeDriver();
			driver.manage().window().maximize();
			driver.get("https://google.com/");

			driver.findElement(By.xpath("//*[@id=\"tsf\"]/div[2]/div/div[1]/div/div[1]/input")).sendKeys(s);
//
//			driver.findElement(
//					By.xpath("//*[@id='tsf']/div[2]/div/div[3]/center/input[@type='submit' and @name='btnK']")).click();
//			Thread.sleep(4000); // **we use this because the page taking time to load so, our script could not
								// executed successfully,
			// By Thread.sleep(millisecond) script has to wait some.
		
			driver.quit();
		}
		wb.close();
	}
}

package com.Test.Util;

import java.io.File;
import java.io.FileInputStream;
//import java.io.FileNotFoundException;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class TestUtil {
	public static void main(String[] args) throws Exception {

	File src = new File("D:\\Suraj_WorkSpace\\Selenium\\src\\com\\testData\\searchData.xlsx");
		
	FileInputStream fis = new FileInputStream(src);
	
	XSSFWorkbook wb = new XSSFWorkbook(fis);
		
	XSSFSheet sheet1 = wb.getSheetAt(0);
String s =	sheet1.getRow(1).getCell(0).getStringCellValue();
	
System.out.println(s);
wb.close();
	}
}

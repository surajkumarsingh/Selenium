package com.Test;

import java.util.Set;
import java.util.Iterator;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HandleWindowPop {

	public static void main(String[] args) throws InterruptedException {
		
		WebDriver driver = new ChromeDriver();
		
		driver.get("http://www.popuptest.com/goodpopups.html");
		
		driver.findElement(By.xpath("//a[text()='Good PopUp #3']")).click();
		
		Thread.sleep(5000);
		
	Set <String> handler =  driver.getWindowHandles();//** to store child window id
	Iterator<String> it = handler.iterator();//**because Set has no index so we use 
	//Iterator to get id of windows instead of for Loop
	//**Window id is unique and Dynamic
	//it.next();// **give you first object
	String parentWindow = it.next();
	System.out.println( "Parent window id "+parentWindow );
	
	String childWindowId = it.next();
	System.out.println("Child Windows id "+childWindowId);
	
	driver.switchTo().window(childWindowId);
	Thread.sleep(2000);
	System.out.println("child window tile "+driver.getTitle());//** once you switched to child
	//window you other action as well
	
	driver.close();//** closes only child window and control goes back to parent window
//	driver.quit();//** closes both parent and child window
	
	driver.switchTo().window(parentWindow);//**** after closing childWindow control is lost
	//so, you have to Switch parent window or any other window
	Thread.sleep(2000);
	System.out.println("parent window title "+driver.getTitle() );
	}

}

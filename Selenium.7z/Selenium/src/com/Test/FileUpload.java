package com.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class FileUpload {

	public static void main(String[] args) throws InterruptedException {
		
WebDriver driver = new ChromeDriver();
 
driver.get("https://html.com/input-type-file/");
//** This will work for upload file scenario**

driver.findElement(By.xpath("//input[@type='file']")).sendKeys("C:\\Users\\suraj_kumar\\Pictures\\December.pdf");
//Thread.sleep(5000);
//driver.close();
	}

}

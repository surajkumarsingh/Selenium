package com.Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Frame {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("file:///C:/Users/suraj_kumar/Desktop/test.htm");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		
		int size = driver.findElements(By.tagName("iframe")).size();
		    System.out.println("Total Frames --" + size);
		
		    driver.switchTo().frame(2);
			size = driver.findElements(By.tagName("iframe")).size();
			 System.out.println("Total  inside Frames --" + size);
	String text = driver.findElement(By.xpath("//h1")).getText();
	System.out.println(text);
	/*JavascriptExecutor js = (JavascriptExecutor) driver;
	 js.executeScript("window.scrollBy(0,document.body.scrollHeight)");*/
			 driver.switchTo().frame(0);
			 text = driver.findElement(By.xpath("//h2")).getText();
				System.out.println(text);
			/* String title =	driver.findElement(By.xpath("//title")).getText();
				System.out.println(title);*/
				size = driver.findElements(By.tagName("iframe")).size();
				 System.out.println("Total  inside Frames --" + size);
	}

}

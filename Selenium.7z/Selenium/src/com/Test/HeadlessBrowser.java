package com.Test;

import java.lang.ref.PhantomReference;
//import org.apache.http.impl.client.HttpClientBuilder;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.testng.annotations.Test;

public class HeadlessBrowser {
	
	static WebDriver driver;

	//public void headLess() throws InterruptedException {
//	WebDriverManager.phantomjs().setup();
	public static void main(String[] args) {
		
		driver = new HtmlUnitDriver();
		driver.get("https://www.google.com");
		
	
		System.out.println(driver.getTitle());
		
		

	}

}

package com.Test;

import org.openqa.selenium.By; 
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class ElementVsibilityTest {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();
		driver.get("https://www.freecrm.com/register/");
		driver.manage().window().maximize();
	
		
		//1. isDisplayed() method: applicable for all elements
boolean b = driver.findElement(By.id("submitButton")).isDisplayed(); 
		System.out.println(b);
		//2. isEnabled Method to check button enabled or not
boolean b1 = driver.findElement(By.xpath("//button[@type='submit']")).isEnabled();
		System.out.println(b1);
		
		//After enabling submit button
		driver.findElement(By.xpath("//input[@type='checkbox']")).click();
		boolean b2 = driver.findElement(By.xpath("//button[@type='submit']")).isEnabled();
		System.out.println(b2);

		//3. isSelected() method: only applicable for checkbox, dropdown, radiobutton
		
	boolean b3 = driver.findElement(By.xpath("//input[@type='checkbox']")).isSelected();
System.out.println(b3);
	
	
	}

}

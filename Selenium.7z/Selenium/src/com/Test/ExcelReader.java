package com.Test;

import java.io.File;
import java.io.FileInputStream;

import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.WebDriver;

public class ExcelReader {

	public static void main(String[] args) throws Exception {
		String name = null;
		String id   = null;

		File src = new File("C:\\Users\\suraj_kumar\\Documents\\QrData.xlsx");

		FileInputStream fis = new FileInputStream(src);

		XSSFWorkbook wb = new XSSFWorkbook(fis);

		XSSFSheet sheet1 = wb.getSheetAt(0);
		int row = sheet1.getLastRowNum();
		System.out.println(row);

		for (int i = 1; i <= row; i++) {
			name = sheet1.getRow(i).getCell(0).getStringCellValue();
			id = sheet1.getRow(i).getCell(1).getStringCellValue();
			System.out.println(name);
			System.out.println(id);
		}
	}
}
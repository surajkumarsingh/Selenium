package com.Test;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Table {
	static WebDriver driver;
	public static void main(String[] args) {
		
		 driver = new ChromeDriver();
		 
		 driver.get("https://www.toolsqa.com/automation-practice-table/#");

   List <WebElement> rows=  driver.findElements(By.xpath("//table[@class='tsc_table_s13']//tr"));
     int rowCount = rows.size();
     System.out.println(rowCount);
     for(int i=1; i<=rowCount-2; i++) {
   String s =  driver.findElement(By.xpath("//*[@id=\"content\"]/table/tbody/tr["+i+"]")).getText();
   System.out.println(s);}
     //String beforeXpath="";
		
		
	}
}

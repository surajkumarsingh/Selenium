package com.Test;

import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import org.testng.annotations.AfterClass;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeClass;
import org.testng.AssertJUnit;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.Reporter;
import org.testng.annotations.*;

//@Listeners(ExtendReportsDemo.class)
public class TestNG {
	WebDriver driver;
	@BeforeClass
public void AsetUp() throws InterruptedException {
	 driver = new ChromeDriver();
	 driver.manage().window().maximize();
	 driver.manage().deleteAllCookies();
	 Reporter.log("Chrome launch successfullys");
	// driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
	// driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	// driver.get("https://www.google.com");
	 	}
	public void facebookTitle() throws InterruptedException {
		 driver.get("https://www.facebook.com/");
		 Thread.sleep(5000);
String s = driver.getTitle();
System.out.println("first class"+s);
AssertJUnit.assertTrue(false);
	}
	
	public void googleLogoTest() {
		driver.get("https://www.google.com");
		Reporter.log("Google url entered");
		boolean b = driver.findElement(By.xpath("//img[@id='hplogo']")).isDisplayed();
		System.out.println(b);
	}
	@AfterClass	
	public void testComplet() {
		driver.close();
	}
}

package com.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;
import org.testng.annotations.Test;

public class KeyPressEvent {
	WebDriver driver;
@Test
public void launchBrowser() throws InterruptedException {
	
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("https://the-internet.herokuapp.com/key_presses");
	Thread.sleep(5000);
	Actions action = new Actions(driver);
	action.sendKeys(Keys.SPACE).build().perform();	
	String text = driver.findElement(By.id("result")).getText();
	System.out.println(text);
	Assert.assertEquals(text, "You entered: SPACE");
}
}

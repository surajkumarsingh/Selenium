package com.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class DynamicElementHandling {

	public static void main(String[] args) {
		WebDriver driver = new ChromeDriver();

		driver.get("https://facebook.com/");
		driver.findElement(By.xpath("//*[contains(@id,'email')]")).sendKeys("suraj");// ** this will check all letters
		// **driver.findElement(By.xpath("//*[starts-with(@id,'em')]")).sendKeys("suraj");//**
		// this will check only starting letter
		driver.findElement(By.xpath("//*[starts-with(@id,'pass')and starts-with(@name,'pass')]")).sendKeys("ssklllkk");
		driver.findElement(By.xpath("//*[starts-with(@id,'pass')and starts-with(@name,'pass')]")).sendKeys(Keys.ENTER);
		
	}

}

package com.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class LocalHostTest {
	WebDriver driver;
@Test
public void BrowserLaunch() {
	
	driver = new ChromeDriver();
	driver.manage().window().maximize();
	driver.get("http://localhost:8030/EmpPortal/Registration.jsp");
	System.out.println("Browser Luanched Successfully");
	
}
@Test 
public void inputTest() {
	driver.findElement(By.xpath("//input[@type='text' and @id='name']")).sendKeys("suraj");
	driver.findElement(By.xpath("//input[@type='text' and @id='id']")).sendKeys("1223");
	driver.findElement(By.xpath("//input[@type='text' and @id='number']")).sendKeys("8737888066");
	driver.findElement(By.xpath("//input[@type='text' and @id='email']")).sendKeys("suraj31@gmail.com");
	driver.findElement(By.xpath("//input[@type='submit' and @id='submit']")).click();
}

@AfterClass
public void closeBrowser() {
	driver.close();
}}
package com.Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class CssSelector {
	WebDriver driver;
	Actions action;
	JavascriptExecutor js;
	String ele;

	@BeforeClass
	public void openBrowser() {
		 System.setProperty("webdriver.ie.driver", "C:\\Users\\suraj_kumar\\Downloads\\IEDriverServer.exe");
		driver = new InternetExplorerDriver();
		action = new Actions(driver);
		driver.manage().window().maximize();
		driver.get("https://www.goibibo.com/flights/");
		driver.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}
	@Test
	public void verifyBooking() throws InterruptedException {
		Thread.sleep(200);
		driver.findElement(By.cssSelector("#gosuggest_inputSrc")).sendKeys("hyderabad");
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[@class='col-md-6 col-sm-6 col-xs-12 pad0']")).click();
		driver.findElement(By.cssSelector("input[id$=Dest]")).sendKeys("delhi");
		Thread.sleep(200);
		driver.findElement(By.xpath("//h1[@class='font30 white lh1-5']")).click();
		Thread.sleep(200);
		driver.findElement(By.xpath("//i[@class='icon-calendar1 ico22 widgetCalIcon ']//self::i")).click();
		String date = "Wed Jan 16 2019";
		driver.findElement(By.xpath("//div[@aria-label='" + date + "']")).click();
		WebElement intrac = driver.findElement(By.cssSelector("i[class='icon-arrow-down txtgrey ico13 lh1-2 padT5 fr']"));
		intrac.click();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).clear();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).sendKeys("9");
		driver.findElement(By.xpath("//a[@id='pax_close']")).click();
		Thread.sleep(2000);
		Select dropDown = new Select(driver.findElement(By.xpath("//select[@id='gi_class']")));
		dropDown.selectByIndex(1);
		driver.findElement(By.xpath("//button[@id='gi_search_btn']")).click();
		// Thread.sleep(2000);
		String url = driver.getCurrentUrl();
		System.out.println(url);
		if (url.contains("air")) {
			System.out.println("Test Passed");
		} else {
			System.out.println("failed");
		}
	}
}

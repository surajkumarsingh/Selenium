package com.Test;

import org.apache.commons.mail.DefaultAuthenticator;
import org.apache.commons.mail.Email;
import org.apache.commons.mail.EmailException;
import org.apache.commons.mail.SimpleEmail;
import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

public class SendMail {

	WebDriver driver;
	Email mail;
	@Test
	public void sendMail() throws EmailException {
		
	mail = new SimpleEmail();
	mail.setHostName("");
	mail.setSmtpPort(465);
	mail.setAuthenticator(new DefaultAuthenticator("userName", "password"));
	mail.setSSLOnConnect(true);
	mail.setFrom("");
	mail.setSubject("");
	mail.setMsg("");
	mail.addTo("");
	mail.send();
	}
}

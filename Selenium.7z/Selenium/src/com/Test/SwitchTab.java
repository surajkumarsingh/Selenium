package com.Test;

import java.util.Set;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

public class SwitchTab {

	

		WebDriver driver;
		@Test
public void switchTabs() {
		driver = new ChromeDriver();
	//	driver.manage().window().maximize();
		driver.get("http://seleniumpractise.blogspot.com/2017/07/multiple-window-examples.html");
		driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL + "t");
		String parent = driver.getWindowHandle();
		/* driver.findElement(By.cssSelector("body")).sendKeys(Keys.CONTROL +"t"); */

		System.out.println("parent window id is" + parent);
		driver.findElement(By.xpath("//a[contains(@href, 'http://www.google.com')]")).click();
		
		Set<String> allWindows = driver.getWindowHandles();
		int count = allWindows.size();
		System.out.println("All windows " + count);

		for (String child : allWindows) {
			if (!parent.equalsIgnoreCase(child)) {
				driver.switchTo().window(child);
				driver.get("https://www.google.com");
				boolean b = driver.findElement(By.xpath("//img[@id='hplogo']")).isDisplayed();
				System.out.println(b);
				driver.close();

			}

		}
		driver.switchTo().window(parent);
		System.out.println(driver.getTitle());
	}

}

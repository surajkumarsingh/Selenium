package com.Test;



import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;
//@Listeners(ExtendReportListner.class)
public class Navigations {
@Test
	public void myntra() throws InterruptedException {
	  
		WebDriver driver= new ChromeDriver();
	  /*   driver = new InternetExplorerDriver();*/
	    // driver = new EdgeDriver();
		driver.manage().window().maximize();
		//driver.manage().timeouts().pageLoadTimeout(5, TimeUnit.SECONDS);
		
		driver.get("https://www.google.com");
		driver.navigate().to("https://www.myntra.com/");// navigate external URL
		Thread.sleep(3000);
		driver.navigate().back();
		Thread.sleep(3000);
		driver.navigate().forward();
		driver.navigate().back();
		//Thread.sleep(5000);
		driver.navigate().refresh();
		
		

	}

}

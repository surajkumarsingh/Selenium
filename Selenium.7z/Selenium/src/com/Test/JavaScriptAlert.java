package com.Test;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class JavaScriptAlert {

	public static void main(String[] args) throws InterruptedException {
		WebDriver driver = new ChromeDriver();
		driver.manage().window().maximize(); // maximize windows size
driver.get("https://mail.rediff.com/cgi-bin/login.cgi");

//driver.findElement(By.name("proceed")).click();	           
	driver.findElement(By.xpath("//input[@type='submit']")).click();
	
	Thread.sleep(5000);
	
	Alert alert = driver.switchTo().alert();// to get text from popup
	
	    System.out.println(alert.getText()); // to get text from popup to check script working or not
	    
	    //alert.sendKeys("");//** to handle prompt box
	  //  alert.accept();// **to click on ok button
	    
	  alert.dismiss();// to click on cancel button
	  driver.switchTo().defaultContent();//not necessary to use 
	   
	   driver.findElement(By.xpath("//input[@id='login1']")).sendKeys("suraj");
	   driver.findElement(By.xpath("//input[@id='password']")).sendKeys("kumar");
	 
	    }
}

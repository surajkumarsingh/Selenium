package com.Test;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.Assert;
import org.testng.annotations.*;


//@Listeners(ExtendReportsDemo.class)
public class Validation {
	WebDriver driver;
	@BeforeClass
	public void setUp() throws InterruptedException {
		 driver = new ChromeDriver();
		 driver.manage().window().maximize();
		 driver.manage().deleteAllCookies();}
	
	@Test(priority = 0)
	public void facebookTitle() throws InterruptedException {
		 driver.get("https://www.facebook.com/");
		 Thread.sleep(5000);
String s = driver.getTitle();
System.out.println(s);
Assert.assertEquals("Facebook � log in or sign up",s,"title not macthed");
	}
	
	@Test(priority = 1)
	public void googleLogoTest() {
		driver.get("https://www.google.com");
		boolean b = driver.findElement(By.xpath("//img[@id='hplogo']")).isDisplayed();
		System.out.println(b);
	Assert.assertTrue(b);
	}
	@AfterClass	
	public void testComplet() {
		driver.close();
}}

package com.Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;

public class DragAndDrop {

	public static void main(String[] args) {
		System.setProperty("webdriver.chrome.driver", "chromedriver.exe");
		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();
		driver.get("https://www.w3schools.com/tags/tryit.asp?filename=tryhtml_iframe");
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
		int size = driver.findElements(By.tagName("iframe")).size();
		//1
		    System.out.println("Total Frames --" + size);
		
		    driver.switchTo().frame("iframeResult");
			size = driver.findElements(By.tagName("iframe")).size();
			//2
			 System.out.println("Total  inside Frames --" + size);
			
			 driver.switchTo().frame(0);
				size = driver.findElements(By.tagName("iframe")).size();
				//3
				 System.out.println("Total  inside Frames --" + size);
			     	
				 driver.switchTo().frame(2);  
				 size = driver.findElements(By.tagName("iframe")).size();
				 System.out.println("Total  inside Frames --" + size);
		String h2 =	driver.findElement(By.xpath("//h4")).getText();
					System.out.println(h2);	
				 driver.switchTo().frame(0);
					size = driver.findElements(By.tagName("iframe")).size();
					/* System.out.println("Total  inside Frames --" + size);
				 h2 =	driver.findElement(By.xpath("//h4")).getText();
					    */
						
					 /* JavascriptExecutor js = (JavascriptExecutor) driver;
					 js.executeScript("window.scrollBy(0,document.body.scrollHeight)");*/
	/*String h2 =	driver.findElement(By.xpath("//title")).getText();
			    
	System.out.println(h2);	    */
/*WebElement frame = driver.findElement(By.xpath("//iframe[@src='https://www.w3schools.com']"));
		
		driver.switchTo().frame(frame);
		//Actions action = new Actions(driver);
	String title =	driver.findElement(By.xpath("//title")).getText();
	System.out.println(title);
*/
		/*action.clickAndHold(driver.findElement(By.xpath("//*[@id='draggable']")))
				.moveToElement(driver.findElement(By.xpath("//*[@id='droppable']"))).release().build().perform();
*/
	}

	}

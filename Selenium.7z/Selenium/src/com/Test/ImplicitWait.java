package com.Test;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
//import org.openqa.selenium.htmlunit.HtmlUnitDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.*;

public class ImplicitWait {
	WebDriver driver;
	Actions action;

	@BeforeClass
	public void setUp() {
		driver = new ChromeDriver();

		// WebDriver driver = new HtmlUnitDriver();

		action = new Actions(driver);
		driver.manage().window().maximize();
	}

	// driver.get("https://www.myntra.com");}
//dynamic wait means if page is loaded within given time then rest time is ignored

//driver.manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
//driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);//wait for all elements to be loaded
	@Test(priority = 1)
	public void firstTest() {
		driver.get("https://www.myntra.com/");

		action.moveToElement(driver.findElement(By.xpath("//a[text()='Men' and @class]"))).build().perform();
		driver.findElement(By.xpath("//a[text()='T-Shirts' and @class='desktop-categoryLink' and @data-reactid]"))
				.click();
	}

	@Test(priority = 1, dependsOnMethods = "firstTest")
	public void secondTest()  throws InterruptedException {
		//driver.get("https://www.myntra.com/men-tshirts");
		//Thread.sleep(5000);
	//	driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	//	WebDriverWait wait = new WebDriverWait(driver, 20);
		//wait.until(ExpectedConditions.invisibilityOfElementLocated(By.xpath("//div/ul[@class='brand-list']/li/label/input[@type='checkbox' and @value='WROGN']")));
	/*WebElement wele = driver.findElement(By.xpath("//div/ul[@class='brand-list']/li/label/input[@type='checkbox' and @value='WROGN']"));	
	JavascriptExecutor executor = (JavascriptExecutor)driver;
	executor.executeScript("arguments[0].click();", wele);*/
	//Thread.sleep(5000);
	/*int x=	driver.findElement(By.xpath("//div/ul[@class='brand-list']/li/label/input[@type='checkbox' and @value='WROGN']")).getLocation().getX();
	int y=	driver.findElement(By.xpath("//div/ul[@class='brand-list']/li/label/input[@type='checkbox' and @value='WROGN']")).getLocation().getX();
	System.out.println("x ="+x+ "y="+y);*/
System.out.println( driver.getCurrentUrl());
boolean b = driver.findElement(By.xpath("//input[@type='checkbox' and @value='WROGN']")).isDisplayed();
System.out.println(b);
	action.moveToElement(driver.findElement(By.xpath("//input[@type='checkbox' and @value='WROGN']"))).click().build().perform();
	Thread.sleep(5000);}@AfterClass
public void closeBrowser() {
		driver.close();
	}
	
}

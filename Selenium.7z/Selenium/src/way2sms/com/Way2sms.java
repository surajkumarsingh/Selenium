package way2sms.com;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.*;
//import com.Test.ExtentReport;

//@Listeners(ExtentReport.class)
public class Way2sms {
	WebDriver driver;
	Actions action;
	XSSFSheet sheet;
	XSSFWorkbook wb;
	DataFormatter formatter;

	@BeforeClass
	public void readexcel() throws IOException {
		File src = new File("Way2sms.xlsx");

		FileInputStream fis = new FileInputStream(src);

		wb = new XSSFWorkbook(fis);

		sheet = wb.getSheetAt(0);
		formatter = new DataFormatter(); // creating formatter using the default locale

	}

	@BeforeMethod
	@Test
	public void launchBrowser() throws InterruptedException {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://www.way2sms.com/");
		// driver.navigate().refresh();
		driver.manage().timeouts().implicitlyWait(15, TimeUnit.SECONDS);
		driver.findElement(By.xpath("//input[@id='mobileNo' and @type='tel']"))
				.sendKeys(formatter.formatCellValue(sheet.getRow(1).getCell(0)));
		driver.findElement(By
				.xpath("//*[@id=\"loginform\"]/div[2]/input[@id='password' and @type='password' and @name='password']"))
				.sendKeys(sheet.getRow(1).getCell(1).getStringCellValue());
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath(
				"//*[@id=\"loginform\"]/div[2]/div[2]//button[@type='button' and @class='btn-theme-sm btn-ls text-uppercase']")))
				.click().build().perform();
		Thread.sleep(3000);
		driver.findElement(By.xpath("//a[@href='Logout' and @class='logout']")).click();
	}

	@Test(dependsOnMethods = "launchBrowser")
	public void loginTest1() {
		System.out.println("s");
		driver.findElement(By.xpath("//input[@id='mobileNo' and @type='tel']"))
				.sendKeys(formatter.formatCellValue(sheet.getRow(1).getCell(0)));
		driver.findElement(By
				.xpath("//*[@id=\"loginform\"]/div[2]/input[@id='password' and @type='password' and @name='password']"))
				.sendKeys(sheet.getRow(1).getCell(1).getStringCellValue());
		Actions action = new Actions(driver);
		action.moveToElement(driver.findElement(By.xpath(
				"//*[@id=\"loginform\"]/div[2]/div[2]//button[@type='button' and @class='btn-theme-sm btn-ls text-uppercase']")))
				.click().build().perform();
		System.out.println("1");
	}

	@Test(dependsOnMethods = "launchBrowser")
	public void loginTest2() {

		driver.findElement(By.xpath(
				"//*[@id=\"loginform\"]/div[2]/div[2]//button[@type='button' and @class='btn-theme-sm btn-ls text-uppercase']"))
				.click();
		System.out.println("2");
	}

	@Test(priority = 3, dependsOnMethods = "launchBrowser")
	public void loginTest3() {

		driver.findElement(By.xpath("//input[@id='mobileNo' and @type='tel']"))
				.sendKeys(formatter.formatCellValue(sheet.getRow(3).getCell(0)));
		driver.findElement(By
				.xpath("//*[@id=\"loginform\"]/div[2]/input[@id='password' and @type='password' and @name='password']"))
				.sendKeys(sheet.getRow(3).getCell(1).getStringCellValue());
		driver.findElement(By.xpath(
				"//*[@id=\"loginform\"]/div[2]/div[2]//button[@type='button' and @class='btn-theme-sm btn-ls text-uppercase']"))
				.click();
		System.out.println("3");
	}

	@Test(priority = 4, dependsOnMethods = "launchBrowser")
	public void loginTest4() {

		driver.findElement(By.xpath("//input[@id='mobileNo' and @type='tel']"))
				.sendKeys(formatter.formatCellValue(sheet.getRow(4).getCell(0)));
		driver.findElement(By
				.xpath("//*[@id=\"loginform\"]/div[2]/input[@id='password' and @type='password' and @name='password']"))
				.sendKeys(sheet.getRow(4).getCell(1).getStringCellValue());
		driver.findElement(By.xpath(
				"//*[@id=\"loginform\"]/div[2]/div[2]//button[@type='button' and @class='btn-theme-sm btn-ls text-uppercase']"))
				.click();
	}

	@Test(priority = 5, dependsOnMethods = "launchBrowser")
	public void loginTest5() {
		driver.findElement(By.xpath("//input[@id='mobileNo' and @type='tel']"))
				.sendKeys(formatter.formatCellValue(sheet.getRow(5).getCell(0)));
		driver.findElement(By
				.xpath("//*[@id=\"loginform\"]/div[2]/input[@id='password' and @type='password' and @name='password']"))
				.sendKeys(sheet.getRow(4).getCell(1).getStringCellValue());
		driver.findElement(By.xpath(
				"//*[@id=\"loginform\"]/div[2]/div[2]//button[@type='button' and @class='btn-theme-sm btn-ls text-uppercase']"))
				.click();
	}

	@Test(priority = 6, dependsOnMethods = "launchBrowser")
	public void loginTest6() {

		driver.findElement(By
				.xpath("//*[@id=\"loginform\"]/div[2]/input[@id='password' and @type='password' and @name='password']"))
				.sendKeys(sheet.getRow(6).getCell(1).getStringCellValue());
		driver.findElement(By.xpath(
				"//*[@id=\"loginform\"]/div[2]/div[2]//button[@type='button' and @class='btn-theme-sm btn-ls text-uppercase']"))
				.click();
	}

	@Test(priority = 7, dependsOnMethods = "launchBrowser")
	public void loginTest7() {

		driver.findElement(By.xpath("//input[@id='mobileNo' and @type='tel']"))
				.sendKeys(formatter.formatCellValue(sheet.getRow(7).getCell(0)));

		driver.findElement(By.xpath(
				"//*[@id=\"loginform\"]/div[2]/div[2]//button[@type='button' and @class='btn-theme-sm btn-ls text-uppercase']"))
				.click();
	}

	@AfterMethod
	public void close() throws InterruptedException {
		Thread.sleep(5000);
		driver.quit();
	}

	@AfterClass
	public void closeExcel() throws IOException {
		wb.close();
	}
}

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Action;
import org.openqa.selenium.interactions.Actions;
import org.testng.annotations.Test;

public class way2smslogo extends TestBaseCrossBrowser{

static Actions action;

	@Test
	public void waysmslogo() throws InterruptedException {
		driver.get("http://www.way2sms.com/");
		 action = new Actions(driver);
		Thread.sleep(2000);
		//action.moveToElement(driver.findElement(By.xpath("//a//b//img[@src='/resources/images/logo-way2sms.png']")).isDisplayed());
boolean b   =	driver.findElement(By.xpath("//a[@class='logo']")).isDisplayed();
System.out.println(b);
WebElement logo   =	driver.findElement(By.xpath("//a[@class='logo']"));
System.out.println(logo);
List<WebElement> logos  =	driver.findElements(By.xpath("//img"));
System.out.println( logos.get(0).getText() );
	}

}

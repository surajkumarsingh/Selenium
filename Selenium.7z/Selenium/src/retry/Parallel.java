package retry;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

public class Parallel {
	WebDriver driver;

	@BeforeMethod

	public void launch() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
	}

	@Test
	public void google() {

		driver.get("https://www.google.com");
	}

	@Test
	public void fb() {
		driver.get("https://www.facebook.com");

	}

	@AfterTest
	public void close() {
		driver.close();
	}
}

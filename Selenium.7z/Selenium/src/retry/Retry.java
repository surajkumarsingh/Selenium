package retry;

import org.testng.Assert;
import org.testng.annotations.Test;

public class Retry {

	@Test
	public void test() {
		
		Assert.assertEquals(false, false);
	}
	
	@Test
public void test2() {
		
Assert.assertEquals(true, false);		
	}
	
}

package dec26;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.apache.poi.hwpf.usermodel.Picture;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.*;
import com.Test.ExtentReportDemo;

//@Listeners(ExtentReportDemo.class)
public class FormTest {
	WebDriver driver;
	Select dropdown;
	XSSFWorkbook wb;
	DataFormatter formatter;
	XSSFSheet sheet;
	Picture pic;

	@BeforeClass
	public void readExcel() throws IOException {
		File src = new File("toolsQa.xlsx");

		FileInputStream fis = new FileInputStream(src);
		formatter = new DataFormatter();
		wb = new XSSFWorkbook(fis);
		sheet = wb.getSheetAt(0);

	}

	@BeforeMethod
	public void launchBrowser() {
		driver = new ChromeDriver();
		driver.manage().window().maximize();
		driver.get("http://toolsqa.com/automation-practice-form/");
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Test(priority = 0, description = "Male Registration")
	public void maleReg() {
		driver.findElement(By.xpath("//input[@type='text' and @name='firstname']"))
				.sendKeys(sheet.getRow(1).getCell(0).getStringCellValue());
		driver.findElement(By.xpath("//input[@type='text' and @name='lastname']"))
				.sendKeys(sheet.getRow(1).getCell(1).getStringCellValue());
		driver.findElement(By.xpath("//input[@type='radio' and @value='Male']")).click();
		driver.findElement(By.xpath("//input[@type='radio' and @value='1']")).click();
		driver.findElement(By.xpath("//input[@type='text' and @id='datepicker']"))
				.sendKeys(formatter.formatCellValue(sheet.getRow(1).getCell(2)));
		driver.findElement(By.xpath("//input[@type='checkbox' and @value='Manual Tester']")).click();
		driver.findElement(By.xpath("//input[@type='checkbox' and @value='Automation Tester']")).click();
		driver.findElement(By.xpath("//input[@type='file' and @name='photo']"))
				.sendKeys("C:\\Users\\suraj_kumar\\Pictures\\Saved Pictures\\google.png");
		driver.findElement(By.xpath("//input[@type='checkbox' and @value='QTP']")).click();
		driver.findElement(By.xpath("//input[@type='checkbox' and @value='Selenium IDE']")).click();
		driver.findElement(By.xpath("//input[@type='checkbox' and @value='Selenium Webdriver']")).click();
		dropdown = new Select(driver.findElement(By.xpath("//select[@id='continents']")));
		dropdown.selectByVisibleText("Asia");
		dropdown = new Select(driver.findElement(By.xpath("//select[@id='selenium_commands']")));
		dropdown.selectByVisibleText("Browser Commands");
		driver.findElement(By.xpath("//button[@id='submit']")).click();
	}

	@Test(priority = 1, description = "Female registration")
	public void femaleReg() {
		driver.findElement(By.xpath("//input[@type='text' and @name='firstname']"))
				.sendKeys(sheet.getRow(2).getCell(0).getStringCellValue());
		driver.findElement(By.xpath("//input[@type='text' and @name='lastname']"))
				.sendKeys(sheet.getRow(2).getCell(1).getStringCellValue());
		driver.findElement(By.xpath("//input[@type='radio' and @value='Female']")).click();
		driver.findElement(By.xpath("//input[@type='radio' and @value='1']")).click();
		driver.findElement(By.xpath("//input[@type='text' and @id='datepicker']"))
				.sendKeys(formatter.formatCellValue(sheet.getRow(2).getCell(2)));
		driver.findElement(By.xpath("//input[@type='checkbox' and @value='Manual Tester']")).click();
		driver.findElement(By.xpath("//input[@type='checkbox' and @value='Automation Tester']")).click();
		driver.findElement(By.xpath("//input[@type='file' and @name='photo']"))
				.sendKeys("C:\\Users\\suraj_kumar\\Pictures\\Saved Pictures\\google.png");
		driver.findElement(By.xpath("//input[@type='checkbox' and @value='QTP']")).click();
		driver.findElement(By.xpath("//input[@type='checkbox' and @value='Selenium IDE']")).click();
		driver.findElement(By.xpath("//input[@type='checkbox' and @value='Selenium Webdriver']")).click();
		dropdown = new Select(driver.findElement(By.xpath("//select[@id='continents']")));
		dropdown.selectByVisibleText("Asia");
		dropdown = new Select(driver.findElement(By.xpath("//select[@id='selenium_commands']")));
		dropdown.selectByVisibleText("Browser Commands");
		driver.findElement(By.xpath("//button[@id='submit']")).click();
	}
	@AfterMethod
	public void end() throws IOException {
		driver.quit();
		//wb.close();
	}
}

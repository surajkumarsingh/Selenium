package goibibo.com;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;
import org.testng.Assert;
import org.testng.annotations.*;

import com.Test.ExtendReportListner;
@Listeners(ExtendReportListner.class)
public class Booking {

	WebDriver driver;
	Actions action;
	JavascriptExecutor js;
	String ele;

	@BeforeMethod
	public void openBrowser() {
		driver = new ChromeDriver();
		action = new Actions(driver);
		driver.manage().window().maximize();
		driver.get("https://www.goibibo.com/flights/");
		driver.manage().timeouts().pageLoadTimeout(3, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}

	@Test(description = "WebSite Accessbility")
	public void webAccess() {
		String title = driver.getTitle();
		Assert.assertEquals(title, "Flight booking, cheap flight tickets, lowest prices - Goibibo");
	}

	@Test(description = "Source city Name populate with city code")
	public void source() throws InterruptedException {
		Thread.sleep(200);
		driver.findElement(By.xpath("//input[@id='gosuggest_inputSrc']")).sendKeys("hyderabad");
		driver.findElement(By.xpath("//input[@id='gosuggest_inputSrc']")).clear();
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[@class='col-md-6 col-sm-6 col-xs-12 pad0']")).click();
		// action.moveToElement(driver.findElement(By.xpath("//div[@id='Home']"))).build().perform();
		// driver.findElement(By.xpath("//input[@id='gosuggest_inputSrc'and
		// @aria-activedescendant='react-autosuggest-1-suggestion--1']")).sendKeys(Keys.ENTER);

		String ele = driver.findElement(By.xpath("//input[@id='gosuggest_inputSrc']")).getAttribute("value");
		System.out.println(ele);
		/*
		 * WebElement ele =
		 * driver.findElement(By.xpath("//input[@id='gosuggest_inputSrc']"));
		 * System.out.println(ele.getAttribute("value"));
		 */

	//	Assert.assertEquals(ele, "Hyderabad (HYD)");
	}

	@Test(description = "Destination city name populate with city code")
	public void destination() throws InterruptedException {
		driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).sendKeys("delhi");
		Thread.sleep(200);
		driver.findElement(By.xpath("//h1[@class='font30 white lh1-5']")).click();
		Thread.sleep(200);
		String ele = driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).getAttribute("value");
		System.out.println(ele);
		Assert.assertEquals(ele, "Delhi (DEL)");
	}

	@Test(description = "select Classes")
	public void selectClass() {
		Select dropDown = new Select(driver.findElement(By.xpath("//select[@id='gi_class']")));
		List<WebElement> options = dropDown.getOptions();
		int size = options.size();
		for (int i = 0; i < size; i++) {
			String actual = options.get(i).getText();
			dropDown.selectByIndex(i);
			WebElement sel = dropDown.getFirstSelectedOption();
			String expected = sel.getText();
			Assert.assertEquals(actual, expected);
		}
	}

	@Test(description = "select Types of Travellers")
	public void Traveller() throws InterruptedException {
		WebElement intrac = driver.findElement(By.xpath("//i[@class='icon-arrow-down txtgrey ico13 lh1-2 padT5 fr']"));
		intrac.click();
		List<WebElement> type = driver.findElements(By.xpath("//span"));
		for (int i = 47; i < 50; i++) {
			System.out.println(type.get(i).getText());
		}
		driver.findElement(By.xpath("//a[@id='pax_close']")).click();
		Thread.sleep(2000);
		String trav = driver.findElement(By.xpath("//span[@id='pax_label']")).getText();
		System.out.println(trav);
		intrac.click();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).clear();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).sendKeys("9");
		driver.findElement(By.xpath("//a[@id='pax_close']")).click();
		Thread.sleep(2000);
		trav = driver.findElement(By.xpath("//span[@id='pax_label']")).getText();
		System.out.println(trav);
	}

	@Test(description = "Testing of date Picker")

	public void datePicker() throws InterruptedException {
		WebElement element = driver.findElement(
				By.xpath("//input[@type='text' and @class='form-control inputTxtLarge widgetCalenderTxt']"));
		String date = "Mon, 31 Dec";
		js = ((JavascriptExecutor) driver);
		js.executeScript("arguments[0].value='" + date + "';", element);
		Thread.sleep(2000);
		// js.executeScript("document.getElementById('datetimepicker').value='"+date+"'");

	}

	@Test
	public void verifyBooking() throws InterruptedException {
		Thread.sleep(200);
		driver.findElement(By.xpath("//input[@id='gosuggest_inputSrc']")).sendKeys("hyderabad");
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[@class='col-md-6 col-sm-6 col-xs-12 pad0']")).click();
		driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).sendKeys("delhi");
		Thread.sleep(200);
		driver.findElement(By.xpath("//h1[@class='font30 white lh1-5']")).click();
		Thread.sleep(200);
		ele = driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).getAttribute("value");
		driver.findElement(By.xpath("//i[@class='icon-calendar1 ico22 widgetCalIcon ']//self::i")).click();
		String date = "Sat Jan 26 2019";
		driver.findElement(By.xpath("//div[@aria-label='" + date + "']")).click();
		WebElement intrac = driver.findElement(By.xpath("//i[@class='icon-arrow-down txtgrey ico13 lh1-2 padT5 fr']"));
		intrac.click();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).clear();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).sendKeys("9");
		driver.findElement(By.xpath("//a[@id='pax_close']")).click();
		Thread.sleep(2000);
		Select dropDown = new Select(driver.findElement(By.xpath("//select[@id='gi_class']")));
		dropDown.selectByIndex(1);
		driver.findElement(By.xpath("//button[@id='gi_search_btn']")).click();
		// Thread.sleep(2000);
		String url = driver.getCurrentUrl();
		System.out.println(url);
		if (url.contains("air")) {
			System.out.println("Test Passed");
		} else {
			System.out.println("failed");
		}
	}

	@Test(description = "shows error Please enter a valid Source")
	public void verifyError1() throws InterruptedException {
		driver.findElement(By.xpath("//div[@class='col-md-6 col-sm-6 col-xs-12 pad0']")).click();
		driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).sendKeys("delhi");
		Thread.sleep(200);
		driver.findElement(By.xpath("//h1[@class='font30 white lh1-5']")).click();
		Thread.sleep(200);
		ele = driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).getAttribute("value");
		driver.findElement(By.xpath("//i[@class='icon-calendar1 ico22 widgetCalIcon ']//self::i")).click();
		String date = "Wed Jan 02 2019";
		driver.findElement(By.xpath("//div[@aria-label='" + date + "']")).click();
		WebElement intrac = driver.findElement(By.xpath("//i[@class='icon-arrow-down txtgrey ico13 lh1-2 padT5 fr']"));
		intrac.click();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).clear();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).sendKeys("9");
		driver.findElement(By.xpath("//a[@id='pax_close']")).click();
		Thread.sleep(2000);
		Select dropDown = new Select(driver.findElement(By.xpath("//select[@id='gi_class']")));
		dropDown.selectByIndex(1);
		driver.findElement(By.xpath("//button[@id='gi_search_btn']")).click();
		Thread.sleep(2000);
		String error = driver
				.findElement(By.xpath("//div[@class='fl width100 txtCenter marginB10 pad5 err-msg']/span/span"))
				.getText();
		if (error.equals("Please enter a valid Source")) {
			System.out.println("Test Passed");
		} else {
			System.out.println("failed");
		}
	}

	@Test(description = "Shows error Source and Destination cannot be same ")
	public void verifyError2() throws InterruptedException {
		driver.findElement(By.xpath("//input[@id='gosuggest_inputSrc']")).sendKeys("hyderabad");
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[@class='col-md-6 col-sm-6 col-xs-12 pad0']")).click();
		driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).sendKeys("hyderabad");
		Thread.sleep(200);
		driver.findElement(By.xpath("//h1[@class='font30 white lh1-5']")).click();
		Thread.sleep(200);
		ele = driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).getAttribute("value");
		driver.findElement(By.xpath("//i[@class='icon-calendar1 ico22 widgetCalIcon ']//self::i")).click();
		String date = "Wed Jan 02 2019";
		driver.findElement(By.xpath("//div[@aria-label='" + date + "']")).click();
		WebElement intrac = driver.findElement(By.xpath("//i[@class='icon-arrow-down txtgrey ico13 lh1-2 padT5 fr']"));
		intrac.click();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).clear();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).sendKeys("9");
		driver.findElement(By.xpath("//a[@id='pax_close']")).click();
		Thread.sleep(2000);
		Select dropDown = new Select(driver.findElement(By.xpath("//select[@id='gi_class']")));
		dropDown.selectByIndex(1);
		driver.findElement(By.xpath("//button[@id='gi_search_btn']")).click();
		Thread.sleep(2000);
		String error = driver
				.findElement(By.xpath("//div[@class='fl width100 txtCenter marginB10 pad5 err-msg']/span/span"))
				.getText();
		if (error.equals("Source and Destination cannot be same")) {
			System.out.println("Test Passed");
		} else {
			System.out.println("failed");
		}
	}

	@Test(description = "Please enter a valid Destination")
	public void verifyError3() throws InterruptedException {
		driver.findElement(By.xpath("//input[@id='gosuggest_inputSrc']")).sendKeys("hyderabad");
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[@class='col-md-6 col-sm-6 col-xs-12 pad0']")).click();
		ele = driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).getAttribute("value");
		driver.findElement(By.xpath("//i[@class='icon-calendar1 ico22 widgetCalIcon ']//self::i")).click();
		String date = "Wed Jan 02 2019";
		driver.findElement(By.xpath("//div[@aria-label='" + date + "']")).click();
		WebElement intrac = driver.findElement(By.xpath("//i[@class='icon-arrow-down txtgrey ico13 lh1-2 padT5 fr']"));
		intrac.click();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).clear();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).sendKeys("9");
		driver.findElement(By.xpath("//a[@id='pax_close']")).click();
		Thread.sleep(2000);
		Select dropDown = new Select(driver.findElement(By.xpath("//select[@id='gi_class']")));
		dropDown.selectByIndex(1);
		driver.findElement(By.xpath("//button[@id='gi_search_btn']")).click();
		Thread.sleep(2000);
		String error = driver
				.findElement(By.xpath("//div[@class='fl width100 txtCenter marginB10 pad5 err-msg']/span/span"))
				.getText();
		if (error.equals("Please enter a valid Destination")) {
			System.out.println("Test Passed");
		} else {
			System.out.println("failed");
		}
	}

	@Test(description = "Please enter a valid departure date")
	public void verifyError4() throws InterruptedException {
		driver.findElement(By.xpath("//input[@id='gosuggest_inputSrc']")).sendKeys("hyderabad");
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[@class='col-md-6 col-sm-6 col-xs-12 pad0']")).click();
		driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).sendKeys("delhi");
		Thread.sleep(200);
		driver.findElement(By.xpath("//h1[@class='font30 white lh1-5']")).click();
		Thread.sleep(200);
		ele = driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).getAttribute("value");
		WebElement intrac = driver.findElement(By.xpath("//i[@class='icon-arrow-down txtgrey ico13 lh1-2 padT5 fr']"));
		intrac.click();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).clear();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).sendKeys("9");
		driver.findElement(By.xpath("//a[@id='pax_close']")).click();
		Thread.sleep(2000);
		Select dropDown = new Select(driver.findElement(By.xpath("//select[@id='gi_class']")));
		dropDown.selectByIndex(1);
		driver.findElement(By.xpath("//button[@id='gi_search_btn']")).click();
		Thread.sleep(2000);
		String error = driver
				.findElement(By.xpath("//div[@class='fl width100 txtCenter marginB10 pad5 err-msg']/span/span"))
				.getText();
		if (error.equals("Please enter a valid departure date")) {
			System.out.println("Test Passed");
		} else {
			System.out.println("failed");
		}
	}

	@Test(description = "shows error Maximum of 9 travellers allowed")
	public void verifyError5() throws InterruptedException {
		driver.findElement(By.xpath("//input[@id='gosuggest_inputSrc']")).sendKeys("hyderabad");
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[@class='col-md-6 col-sm-6 col-xs-12 pad0']")).click();
		driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).sendKeys("delhi");
		Thread.sleep(200);
		driver.findElement(By.xpath("//h1[@class='font30 white lh1-5']")).click();
		Thread.sleep(200);
		ele = driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).getAttribute("value");
		driver.findElement(By.xpath("//i[@class='icon-calendar1 ico22 widgetCalIcon ']//self::i")).click();
		String date = "Wed Jan 02 2019";
		driver.findElement(By.xpath("//div[@aria-label='" + date + "']")).click();
		WebElement intrac = driver.findElement(By.xpath("//i[@class='icon-arrow-down txtgrey ico13 lh1-2 padT5 fr']"));
		intrac.click();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).clear();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).sendKeys("9");
		driver.findElement(By.xpath("//input[@id='childPaxBox']")).clear();
		driver.findElement(By.xpath("//input[@id='childPaxBox']")).sendKeys("6");
		Thread.sleep(2000);
		Select dropDown = new Select(driver.findElement(By.xpath("//select[@id='gi_class']")));
		dropDown.selectByIndex(1);
		Thread.sleep(2000);
		String error = driver.findElement(By.xpath("//span[@class='status_cont']")).getText();
		if (error.equals("Maximum of 9 travellers allowed")) {
			System.out.println("Test Passed");
		} else {
			System.out.println("failed");
		}
	}

	@Test(description = "shows error Number of infants cannot be more than adults")
	public void verifyError6() throws InterruptedException {
		driver.findElement(By.xpath("//input[@id='gosuggest_inputSrc']")).sendKeys("hyderabad");
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[@class='col-md-6 col-sm-6 col-xs-12 pad0']")).click();
		driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).sendKeys("delhi");
		Thread.sleep(200);
		driver.findElement(By.xpath("//h1[@class='font30 white lh1-5']")).click();
		Thread.sleep(200);
		ele = driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).getAttribute("value");
		driver.findElement(By.xpath("//i[@class='icon-calendar1 ico22 widgetCalIcon ']//self::i")).click();
		String date = "Wed Jan 02 2019";
		driver.findElement(By.xpath("//div[@aria-label='" + date + "']")).click();
		WebElement intrac = driver.findElement(By.xpath("//i[@class='icon-arrow-down txtgrey ico13 lh1-2 padT5 fr']"));
		intrac.click();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).clear();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).sendKeys("3");
		driver.findElement(By.xpath("//input[@id='infantPaxBox']")).clear();
		driver.findElement(By.xpath("//input[@id='infantPaxBox']")).sendKeys("6");
		Thread.sleep(2000);
		Select dropDown = new Select(driver.findElement(By.xpath("//select[@id='gi_class']")));
		dropDown.selectByIndex(1);
		Thread.sleep(2000);
		String error = driver.findElement(By.xpath("//span[@class='status_cont']")).getText();
		if (error.equals("Number of infants cannot be more than adults")) {
			System.out.println("Test Passed");
		} else {
			System.out.println("failed");
		}
	}

	@Test
	public void verifyBooking2() throws InterruptedException {
		driver.findElement(By.xpath("//input[@id='gosuggest_inputSrc']")).sendKeys("kota");
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[@class='col-md-6 col-sm-6 col-xs-12 pad0']")).click();
		driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).sendKeys("bangalore");
		Thread.sleep(200);
		driver.findElement(By.xpath("//h1[@class='font30 white lh1-5']")).click();
		Thread.sleep(200);
		ele = driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).getAttribute("value");
		driver.findElement(By.xpath("//i[@class='icon-calendar1 ico22 widgetCalIcon ']//self::i")).click();
		String date = "Wed Jan 02 2019";
		driver.findElement(By.xpath("//div[@aria-label='" + date + "']")).click();
		WebElement intrac = driver.findElement(By.xpath("//i[@class='icon-arrow-down txtgrey ico13 lh1-2 padT5 fr']"));
		intrac.click();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).clear();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).sendKeys("9");
		driver.findElement(By.xpath("//a[@id='pax_close']")).click();
		Thread.sleep(2000);
		Select dropDown = new Select(driver.findElement(By.xpath("//select[@id='gi_class']")));
		dropDown.selectByIndex(1);
		driver.findElement(By.xpath("//button[@id='gi_search_btn']")).click();
		String url = driver.getCurrentUrl();
		String error = driver.findElement(By.xpath("//div[@class='clearfix txtCenter ico20 padTB10']")).getText();
		System.out.println(url);
		if (url.contains("air") && error.equals("Sorry, we could not find any flights for this route")) {
			System.out.println("Test Passed");
		} else {
			System.out.println("failed");
		}
	}

	@Test
	public void filterTime() throws InterruptedException {
		Thread.sleep(200);
		driver.findElement(By.xpath("//input[@id='gosuggest_inputSrc']")).sendKeys("hyderabad");
		Thread.sleep(200);
		driver.findElement(By.xpath("//div[@class='col-md-6 col-sm-6 col-xs-12 pad0']")).click();
		driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).sendKeys("delhi");
		Thread.sleep(200);
		driver.findElement(By.xpath("//h1[@class='font30 white lh1-5']")).click();
		Thread.sleep(200);
		ele = driver.findElement(By.xpath("//input[@id='gosuggest_inputDest']")).getAttribute("value");
		driver.findElement(By.xpath("//i[@class='icon-calendar1 ico22 widgetCalIcon ']//self::i")).click();
		String date = "Tue Jan 08 2019";
		driver.findElement(By.xpath("//div[@aria-label='" + date + "']")).click();
		WebElement intrac = driver.findElement(By.xpath("//i[@class='icon-arrow-down txtgrey ico13 lh1-2 padT5 fr']"));
		intrac.click();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).clear();
		driver.findElement(By.xpath("//input[@id='adultPaxBox']")).sendKeys("1");
		driver.findElement(By.xpath("//a[@id='pax_close']")).click();
		Thread.sleep(2000);
		Select dropDown = new Select(driver.findElement(By.xpath("//select[@id='gi_class']")));
		dropDown.selectByIndex(1);
		driver.findElement(By.xpath("//button[@id='gi_search_btn']")).click();
		action.moveToElement(driver.findElement(By.xpath("//a[@id='timesFilter']"))).build().perform();
		Thread.sleep(5000);
		List<WebElement> slots = driver.findElements(By.xpath("//span[@class='navTimeSlotBlk ']//child::small"));
		int list = slots.size();
		String xpath;
		for (int j = 0; j <= list - 1; j++) {
			xpath = slots.get(j).getText();
			if (j == 0) {
				xpath = "Before 11AM";
				driver.findElement(By.xpath("//small[text()='" + xpath + "']")).click();
				List<WebElement> time = driver.findElements(By.xpath("//span[text()='HYD']//child::span"));
				  int size = time.size(); 
				        for (int i = 0; i < size - 1; i++) {   
				        	
				     }	 
				   driver.findElement(By.xpath("//a[text()='Reset Filters']")).click();    
				   System.out.println("Before 11AM Passed");
			} else if (j == 3) {
				xpath = "After 9";
			}
			driver.findElement(By.xpath("//small[text()='" + xpath + "']")).click();
			System.out.println(driver.findElement(By.xpath("//small[text()='" + xpath + "']")).getText());
			List<WebElement> time = driver.findElements(By.xpath("//span[text()='HYD']//child::span"));
			  int size = time.size(); 
			        for (int i = 0; i < size - 1; i++) { 
			  }	 
		}
	}

	@AfterMethod
	public void close() {
		driver.close();
	}
}

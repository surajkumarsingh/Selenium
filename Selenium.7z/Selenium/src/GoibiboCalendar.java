import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class GoibiboCalendar {

	public static void main(String[] args) {
		System.setProperty("webdriver.edge.driver","D:\\Suraj_WorkSpace\\Selenium\\MicrosoftWebDriver.exe");  
		WebDriver driver = new EdgeDriver();
		driver.manage().window().maximize();
		driver.get("https://www.goibibo.com/flights");
		// input[contains(@id,'gosuggest_inputSrc')]
		// input[starts-with(@id,'gosuggest_inputSrc')]
		// input[starts-with(@id,'gosuggest_inputSrc') and @type='text']
		// driver.findElement(By.xpath("//input[@type='radio']//following::input[3]")).sendKeys("h");

		/*
		 * driver.findElement(By.
		 * xpath("//input[@class='form-control inputTxtLarge widgetCalenderTxt']//self::input"
		 * )) .click();
		 */
		// driver.findElement(By.xpath("//input[@type='text']//following::input[3]")).click();
		////div[@id='searchWidgetNew']//child::input//following::input[3]//self::input.click();
		//driver.findElement(By.xpath("//i[@class='icon-calendar1 ico22 widgetCalIcon ']//self::i")).click();
		/*
		 * Method 1 String date = "Wed Jan 02 2019";
		 * driver.findElement(By.xpath("//div[@aria-label='"+date+"']")).click();
		 * 
		 *second calendar xpath
		 *1.//div[@id='searchWidgetNew']//following::i[@class='icon-calendar1 ico22 widgetCalIcon '][2]
		 *2.//div[@id='searchWidgetNew']//span[contains(text(),'Return:')]//following::input[1] 
		 *3.//span[contains(text(),'Return:')]//following::i[1]
		 *4.//span[contains(text(),'Return:')]//following::input[1]
		 *5.//div[@id='searchWidgetNew']//child::span[contains(text(),'Return:')]
		 */
	/*	List<WebElement> dates = driver.findElements(By.xpath("//div[@class='calDate']"));
		int size = dates.size();
		int i;
		System.out.println(size);
		for (i = 0; i < size - 1; i++) {
			String comp = dates.get(i).getText();
			String date = "28";
			if (comp.equals(date)) {
				dates.get(i).click();
				break;
			}
		}
		System.out.println(i);

		driver.findElement(By.xpath("//button[@id='gi_search_btn']")).click();*/
	}

}

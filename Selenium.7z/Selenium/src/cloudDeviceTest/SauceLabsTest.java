package cloudDeviceTest;

import java.net.MalformedURLException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;

public class SauceLabsTest {

	public static final String USERNAME = "surajkumar";

	public static final String ACCESSKEY = "35b3c0c6-7186-4dfc-807e-46bb876c4ba2";

	public static final String URL = "http://" + USERNAME + ":" + ACCESSKEY + "@ondemand.saucelabs.com:80/wd/hub";

	public static void main(String[] args) throws MalformedURLException {

		DesiredCapabilities cap = new DesiredCapabilities();

		cap.setCapability("platform", "Windows 10");
		cap.setCapability("browserName", "Chrome");
		cap.setCapability("version", "latest");
		cap.setCapability("name", "Demo");

		WebDriver driver = new RemoteWebDriver(new java.net.URL(URL), cap);

		driver.get("https://www.youtube.com/");

	}

}

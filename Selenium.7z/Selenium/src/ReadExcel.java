import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

//How to read excel files using Apache POI
public class ReadExcel {
	public static void main (String [] args) throws IOException{
                        //I have placed an excel file 'Test.xlsx' in my D Driver 
			FileInputStream fis = new FileInputStream("D:\\Suraj_WorkSpace\\Selenium\\src\\com\\testData\\Way2sms.xlsx");
			XSSFWorkbook workbook = new XSSFWorkbook(fis);
			XSSFSheet sheet = workbook.getSheetAt(0);
                      
			DataFormatter formatter = new DataFormatter(); //creating formatter using the default locale
			// Cell cell = sheet.getRow(1).getCell(0);
			// String s = formatter.formatCellValue(cell); //Returns the formatted value of a cell as a String regardless of the cell type.
		//	Row row = sheet.getRow(0);
			// cell = row.getCell(0);
                       	//System.out.println(s);
			System.out.println(formatter.formatCellValue(sheet.getRow(2).getCell(1)));
			//String cellval = cell.getStringCellValue();
			//System.out.println(cellval);
			
	}		
}
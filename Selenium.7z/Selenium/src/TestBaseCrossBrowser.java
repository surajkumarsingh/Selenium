import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.testng.annotations.Parameters;

public class TestBaseCrossBrowser {

	static WebDriver driver;
	public static void initializtion(String browserName) {
		System.out.println("In Testbase "+browserName);

		try {
			
		  if(browserName.equalsIgnoreCase("edge")) {	
				System.setProperty("webdriver.edge.driver", "D:\\Suraj_WorkSpace\\Selenium\\MicrosoftWebDriver.exe");
				driver = new EdgeDriver();
				} 
			else if (browserName.equalsIgnoreCase("chrome")) {
				System.setProperty("webdriver.chrome.driver", "D:\\Suraj_WorkSpace\\Selenium\\chromedriver.exe");
				//Thread.sleep(5000);
				driver = new ChromeDriver();
				driver.manage().deleteAllCookies();
			} 
			else if (browserName.equalsIgnoreCase("ie")) {
				System.setProperty("webdriver.ie.driver", "D:\\Suraj_WorkSpace\\Selenium\\IEDriverServer.exe");
				driver = new InternetExplorerDriver();
				//driver.manage().deleteAllCookies();
				
			}
			/*} else if (browserName.equalsIgnoreCase("fireFox")) {
				System.setProperty("webdriver.gecko.driver", "D:\\Suraj_WorkSpace\\Selenium\\geckodriver.exe");
				driver = new FirefoxDriver();*/
			
			else{
				//If no browser passed throw exception
			System.out.println("Browser is not correct");
			}
		} catch (Exception e) {
			
			e.printStackTrace();
		}
		//driver.manage().window().maximize();
		
		driver.get("https://www.goibibo.com/flights/");
		//driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
		// driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	//	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);

	}
}


import java.util.concurrent.TimeUnit;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

public class CrossBrowser extends TestBaseCrossBrowser {


@BeforeTest
@Parameters("browser")
public void setup(String browserName)  {
	initializtion(browserName);
	System.out.println(browserName);
	driver.get("https://www.goibibo.com/flights/");
	//driver.manage().timeouts().pageLoadTimeout(60, TimeUnit.SECONDS);
	driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
}
	@Test
	public void goibiboTitle() {
	System.out.println(driver.getTitle());	


	}
	
	@AfterTest
	public void tearDown() {
		driver.quit();
		
	}
}

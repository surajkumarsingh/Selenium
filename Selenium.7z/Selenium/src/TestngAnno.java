import org.testng.annotations.*;
import org.testng.annotations.Test;
public class TestngAnno {
	@BeforeMethod
	public void beforeMethod() {
	
	System.out.println(" Before Method will execute before every test method");
	
	}

	@Test(priority=2)
	public void testCase1() {

		System.out.println("This is my First Test Case 1");

	}

	@Test(priority=1)
	public void testCase2() {

		System.out.println("This is my Second Test Case 2");

	}

}

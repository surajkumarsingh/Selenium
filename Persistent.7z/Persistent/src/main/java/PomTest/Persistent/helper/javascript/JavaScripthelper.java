package PomTest.Persistent.helper.javascript;

import org.apache.log4j.Logger;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import PomTest.Persistent.helper.logger.LoggerHelper;
/**
 * 
 * @author suraj_kumar
 *
 */
public class JavaScripthelper {

	private WebDriver driver;

	private Logger log = LoggerHelper.getLogger(JavaScripthelper.class);

	public JavaScripthelper(WebDriver driver) {
		this.driver = driver;
		log.info("JavaScripthelper has been initialised");
	}

	/**
	 * This Method will execute javaScript
	 * 
	 * @param script
	 * @return
	 */
	public Object executeScript(String script) {

		JavascriptExecutor exe = (JavascriptExecutor) driver;
		return exe.executeScript(script);
	}

	/**
	 * This Method will execute Java script with multiple arguments
	 * 
	 * @param script
	 * @param args
	 * @return
	 */
	public Object executeScript(String script, Object... args) {

		JavascriptExecutor exe = (JavascriptExecutor) driver;
		return exe.executeScript(script);
	}

	/**
	 * This Method will scroll till element
	 * 
	 * @param element
	 */
	public void scrollToElement(WebElement element) {
		log.info("scroll to Webelement....");
		executeScript("window.scrollTo(argument[0],argument[1])", element.getLocation().x, element.getLocation().y);
	}

	/**
	 * Scroll till Element and click
	 * 
	 * @param element
	 */
	public void scrollToElemntAndClick(WebElement element) {
		scrollToElement(element);
		element.click();
		log.info("element is clicked : " + element.toString());
	}

	/**
	 * Scroll till view element
	 * 
	 * @param element
	 */
	public void scrollIntoView(WebElement element) {
		executeScript("argument[0].scrollIntoView()", element);
	}

	public void scrollIntoViewAndClick(WebElement element) {
		scrollIntoView(element);
		element.click();
		log.info("element is clicked :" + element.toString());
	}

	public void scrollDownVertically() {
		log.info("scrolling down vertically...");
		executeScript("window.scrollTo(0,document.body.scrollHeight)");
	}

	public void scrollupVertically() {
		log.info("scrolling up vertically...");
		executeScript("window.scrollTo(0,-document.body.scrollHeight)");
	}

	/**
	 * scroll up by given pixel
	 * 
	 * @param pixel
	 */
	public void scrollUpByPixel(int pixel) {
		executeScript("window.scrollBy(0,-" + pixel + ")");
	}

	/**
	 * Scroll till given pixel
	 * 
	 * @param pixel
	 */
	public void scrollDownByPixel(int pixel) {
		executeScript("window.scrollBy(0," + pixel + ")");
	}

	/**
	 * This method will ZOOM scree by 100%
	 */
	public void zoomInBy100Percent() {
		executeScript("document.body.style.zoom='100%'");
	}

	/**
	 * This will zoom screen by 60%
	 */
	public void zoomInBy60Percent() {
		executeScript("document.body.style.zoom='60%'");
	}

	/**
	 * This method will click on element
	 * 
	 * @param element
	 */
	public void click(WebElement element) {
		executeScript("argument.click();", element);
	}
}

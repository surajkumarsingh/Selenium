package PomTest.Persistent.helper.window;

import java.util.Set;

import org.apache.log4j.Logger;
import org.openqa.selenium.WebDriver;

import PomTest.Persistent.helper.logger.LoggerHelper;

public class WindowHelper {

	private WebDriver driver;

	private Logger log = LoggerHelper.getLogger(WindowHelper.class);

	public WindowHelper(WebDriver driver) {
		this.driver = driver;
	}

	/**
	 * This Method will switch to Parent Window
	 */
	public void switchToParentWindow() {
		log.info("Switching to Parent window");
		driver.switchTo().defaultContent();
	}

	/**
	 * This Method will Switch to child Window Based on Index
	 * 
	 * @param WindowIndex
	 */
	public void switchToWindow(int WindowIndex) {
		Set<String> windows = driver.getWindowHandles();
		int i = 1;
		for (String window : windows) {
			if (i == WindowIndex) {
				log.info("switched to : "+WindowIndex+" window");
				driver.switchTo().window(window);
			} else {
				i++;
			}
		}
	}

	/**
	 * This method will close all tabbed window and switch to main window
	 */
	public void closeAllTabsAndSwitchToMainWindow() {
		Set<String> windows = driver.getWindowHandles();
		String mainwindow = driver.getWindowHandle();
		for (String window : windows) {
			if (!window.equalsIgnoreCase(mainwindow)) {
				driver.close();
			}
		}
		log.info("switched to main window");
		driver.switchTo().window(mainwindow);
	}
/**
 * This Method will do Browser back navigation
 */
	public void navigateBack() {
		log.info("Navigating Backward");
		driver.navigate().back();
	}
/**
 * This Method will do Browser forward navigation
 */
	public void navigateForward() {
		log.info("Navigating Forward");
		driver.navigate().forward();
	}
/**
 * This Method will Refresh the window 
 */
	public void windowRefresh() {
		log.info("Refreshing Window");
		driver.navigate().refresh();
	}
}

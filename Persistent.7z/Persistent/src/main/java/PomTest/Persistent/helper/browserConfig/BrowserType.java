package PomTest.Persistent.helper.browserConfig;

public enum BrowserType {
	Firefox,
	Iexpoler,
	chrome,
	Edeg,
	Opera,
	Safari
}

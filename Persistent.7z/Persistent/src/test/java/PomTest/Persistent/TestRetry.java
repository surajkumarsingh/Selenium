package PomTest.Persistent;

import org.testng.annotations.Test;

import PomTest.Persistent.testbase.TestBase;

import org.testng.Assert;

public class TestRetry  {

@Test
public void test1() {
	Assert.assertTrue(true);
}
@Test
public  void test2() {
	Assert.assertTrue(true);
}
@Test
public  void test3() {
	Assert.assertTrue(true);}
}

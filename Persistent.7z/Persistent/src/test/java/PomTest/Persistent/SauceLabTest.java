package PomTest.Persistent;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.testng.Assert;
import org.testng.ITestResult;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.Test;
 
import java.lang.reflect.Method;
import java.net.MalformedURLException;
import java.net.URL;
 
public class SauceLabTest {
 
   
public static final  String sauceUserName = "surajkumar";
public static final  String sauceAccessKey = "35b3c0c6-7186-4dfc-807e-46bb876c4ba2";
public static final  String sauceURL = "https://" + sauceUserName + ":" +sauceAccessKey  + "@ondemand.saucelabs.com:443/wd/hub";
 
   public static void main(String[] args) throws MalformedURLException {
	

        DesiredCapabilities capabilities = new DesiredCapabilities().chrome();
       /* capabilities.setCapability("username", sauceUserName);
        capabilities.setCapability("accessKey", sauceAccessKey);*/
      // capabilities.setCapability("browserName", "chrome");
        capabilities.setCapability("platform", "Windows 10");
        capabilities.setCapability("version", "latest");
      //  capabilities.setCapability("name", "2-user-site");
WebDriver driver  = new RemoteWebDriver(new java.net.URL(sauceURL), capabilities);       
        
driver.get("https://www.youtube.com");
System.out.println(driver.getCurrentUrl());
driver.quit();

   }
      
 
       
}